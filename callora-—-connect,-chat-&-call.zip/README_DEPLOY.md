# 🚀 Callora (কলরা) — Next-Gen Encrypted Voice, Video & Chat Web App

Callora হলো একটি সর্বাধুনিক সাইবার-স্পেস ডার্ক থিমযুক্ত পিয়ার-টু-পিয়ার এবং ক্লাউড কানেক্টেড কমিউনিকেশন প্ল্যাটফর্ম। ফোন নম্বরের প্রয়োজন ছাড়াই **১১-সংখ্যার ইউনিক Virtual ID (`210XXXXXXXX`)** দিয়ে যেকোনো সময় ১০০% নিরাপদ অডিও কল, HD ভিডিও কল এবং মেসেজিং করা যায়।

---

## ⚡ ফায়ারবেস কনফিগারেশন (Connected to `callora9`):
```javascript
const firebaseConfig = {
  apiKey: "AIzaSyBd85pzo16nS5aWs7lqaMgS9Z2ai0P2t2E",
  authDomain: "callora9.firebaseapp.com",
  projectId: "callora9",
  storageBucket: "callora9.firebasestorage.app",
  messagingSenderId: "499528760380",
  appId: "1:499528760380:web:6b06f20a039f0234121739",
  measurementId: "G-7QV40087HJ"
};
```

---

## 🌟 প্রধান প্রধান ফিচারসমূহ:

1. **ইউনিক ১১-সংখ্যার Virtual ID (`210XXXXXXXX`):**
   - কোনো ফেক ডেমো ইউজার বা অযাচিত কন্ট্যাক্ট থাকবে না। নতুন ইউজারদের জন্য সম্পূর্ণ ফ্রেশ ও ক্লিন ইন্টারফেস।
   - শুধুমাত্র যাকে আপনি ১১-সংখ্যার আইডি দিয়ে সার্চ করে যুক্ত করবেন অথবা যে আপনাকে মেসেজ/কল করবে কেবল তারাই আপনার তালিকায় থাকবে।
2. **ডাইরেক্ট ইনভাইট লিঙ্ক:**
   - যেকোনো ব্রাউজারে `https://your-domain.com/#id=21088492011` বা `?id=21088492011` লিঙ্ক ওপেন করলেই সরাসরি সেই ব্যক্তির সাথে চ্যাট ওপেন হয়ে যাবে।
3. **WebRTC অডিও ও HD ভিডিও কল:**
   - লো-লেটেন্সি পিয়ার-টু-পিয়ার ভয়েস এবং ভিডিও কলিং।
   - ইনকামিং কল নোটিফিকেশন ও রিংটোন।
   - মাইক্রোফোন মিউট, ক্যামেরা সুইচ, স্ক্রিন শেয়ার এবং ড্র্যাগযোগ্য পিকচার-ইন-পিকচার (PiP)।
4. **রিচ চ্যাট ও ভয়েস রেকর্ডার:**
   - ভয়েস মেসেজ রেকর্ড ও অডিও ওয়েভফর্ম প্লেয়ার।
   - ফটো ও ইমেজ এটাচমেন্ট।
   - ইমোজি রিঅ্যাকশন (❤️, 👍, 😂, 🔥, 😮)।
   - বাংলা/ইংরেজি AI অ্যাসিস্ট্যান্ট।

---

## 💻 লোকাল মেশিনে রান করার উপায় (Run Locally):

```bash
# ১. ডিপেন্ডেন্সি ইনস্টল করুন
npm install

# ২. লোকাল ডেভ সার্ভার চালু করুন (Port 3000)
npm run dev
```

---

## 🌐 অনলাইনে আপলোড / ডেপ্লয় করার উপায় (Deploy Online):

### অপশন ১: Firebase Hosting (Recommended for `callora9`)
```bash
# ১. প্রজেক্ট বিল্ড করুন
npm run build

# ২. Firebase CLI লগইন করুন
npx firebase-tools login

# ৩. callora9 প্রজেক্টে ডেপ্লয় করুন
npx firebase-tools use callora9
npx firebase-tools deploy
```
*আপনার অ্যাপ সরাসরি `https://callora9.web.app` এ লাইভ হয়ে যাবে!*

### অপশন ২: Vercel এ ডেপ্লয় (১-ক্লিকে)
1. গিটহাবে কোড পুশ করুন (`git push origin main`)
2. [vercel.com](https://vercel.com) এ গিয়ে `Import Project` সিলেক্ট করুন।
3. Framework Preset: `Vite` রাখুন এবং `Deploy` বাটনে চাপ দিন।

### অপশন ৩: Netlify এ ডেপ্লয়
1. [netlify.com](https://netlify.com) এ লগইন করে `dist` ফোল্ডারটি ড্র্যাগ অ্যান্ড ড্রপ করুন অথবা GitHub কানেক্ট করুন।
2. Build Command: `npm run build`
3. Publish Directory: `dist`

---
🎉 **Callora প্রস্তুত! সম্পূর্ণ নিরাপদ ও স্বাধীনভাবে কল এবং চ্যাট উপভোগ করুন।**
