export interface UserProfile {
  uid: string;
  name: string;
  username?: string;
  email: string;
  virtualId: string; // 11-digit string e.g. "21088492011"
  photoURL?: string;
  avatarBg?: string;
  bio?: string;
  statusText?: string;
  online: boolean;
  lastSeen?: number | string;
  createdAt?: number | string;
  contacts?: string[]; // array of contact uids
}

export type MessageType = 'text' | 'image' | 'audio' | 'call_log' | 'file';

export interface Reaction {
  emoji: string;
  count: number;
  users: string[]; // uids
}

export interface ChatMessage {
  id: string;
  chatId: string;
  senderId: string;
  receiverId?: string; // or groupId
  text: string;
  type: MessageType;
  mediaUrl?: string;
  audioDuration?: number;
  fileName?: string;
  fileSize?: string;
  createdAt: number;
  status?: 'sending' | 'sent' | 'delivered' | 'read';
  reactions?: Record<string, string[]>; // emoji -> array of uids
  replyTo?: {
    id: string;
    text: string;
    senderName: string;
  };
}

export interface ChatThread {
  id: string;
  type: 'direct' | 'group';
  participants: string[]; // uids
  participantDetails?: Record<string, UserProfile>;
  name?: string; // For groups
  avatar?: string;
  lastMessage?: string;
  lastMessageType?: MessageType;
  lastSenderId?: string;
  updatedAt: number;
  unreadCount?: number;
  pinned?: boolean;
}

export interface GroupDetails {
  id: string;
  name: string;
  description: string;
  avatar: string;
  createdBy: string;
  admins: string[];
  members: string[];
  createdAt: number;
}

export interface CallSession {
  callId: string;
  callerId: string;
  callerName: string;
  callerAvatar?: string;
  callerVirtualId?: string;
  receiverId: string;
  receiverName: string;
  receiverAvatar?: string;
  type: 'audio' | 'video';
  status: 'calling' | 'ringing' | 'connected' | 'ended' | 'declined';
  startTime?: number;
  duration?: number;
  offer?: RTCSessionDescriptionInit;
  answer?: RTCSessionDescriptionInit;
}

export type ActiveTab = 'chats' | 'contacts' | 'groups' | 'ai' | 'settings';
