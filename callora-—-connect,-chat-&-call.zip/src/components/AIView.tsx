import React, { useState, useRef, useEffect } from 'react';
import {
  Bot,
  Sparkles,
  Send,
  Trash2,
  Copy,
  Check,
  Zap,
  Languages,
  MessageSquarePlus,
  HelpCircle
} from 'lucide-react';
import { AIMessage, askCalloraAI } from '../services/gemini';
import { sound } from '../services/sound';

export const AIView: React.FC = () => {
  const [messages, setMessages] = useState<AIMessage[]>([
    {
      id: 'welcome_ai',
      role: 'assistant',
      content: `আসসালামু আলাইকুম! আমি **Callora AI** — আপনার সার্বক্ষণিক স্মার্ট অ্যাসিস্ট্যান্ট। 🤖✨
      
আপনি আমাকে দিয়ে যা করতে পারেন:
• যেকোনো টেক্সট বাংলা বা ইংরেজিতে নির্ভুল অনুবাদ।
• বন্ধুদের বা ক্লায়েন্টদের পাঠানোর জন্য সুন্দর মেসেজ ড্রাফট করা।
• WebRTC, কোডিং, প্রযুক্তি বা সাধারণ জ্ঞান বিষয়ক প্রশ্নের উত্তর জানা।
• ভার্চুয়াল আইডি ও কলরা প্ল্যাটফর্ম ব্যবহারের টিপস।

আজ আমি আপনাকে কীভাবে সহায়তা করতে পারি?`,
      timestamp: Date.now()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleSend = async (customPrompt?: string) => {
    const promptToSend = customPrompt || inputText;
    if (!promptToSend.trim() || loading) return;

    const userMsg: AIMessage = {
      id: `u_${Date.now()}`,
      role: 'user',
      content: promptToSend.trim(),
      timestamp: Date.now()
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!customPrompt) setInputText('');
    setLoading(true);
    sound.playMessageSent();

    try {
      const reply = await askCalloraAI(promptToSend, messages);
      const assistantMsg: AIMessage = {
        id: `ai_${Date.now()}`,
        role: 'assistant',
        content: reply,
        timestamp: Date.now()
      };
      setMessages((prev) => [...prev, assistantMsg]);
      sound.playMessageReceived();
    } catch {
      const fallbackMsg: AIMessage = {
        id: `ai_err_${Date.now()}`,
        role: 'assistant',
        content: 'দুঃখিত, এই মুহূর্তে উত্তর তৈরিতে কিছুটা সমস্যা হয়েছে। অনুগ্রহ করে আবার প্রশ্নটি করুন।',
        timestamp: Date.now()
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const quickPrompts = [
    { icon: <Languages className="w-3.5 h-3.5" />, label: 'বাংলায় অনুবাদ করো', prompt: 'Please explain the benefits of end-to-end encrypted messaging in simple Bengali.' },
    { icon: <MessageSquarePlus className="w-3.5 h-3.5" />, label: 'মিটিংয়ের মেসেজ ড্রাফট', prompt: 'কালকের প্রজেক্ট মিটিং সংক্রান্ত একটি চমৎকার সংক্ষিপ্ত মেসেজ বাংলায় লিখে দাও।' },
    { icon: <HelpCircle className="w-3.5 h-3.5" />, label: 'Virtual ID কী?', prompt: 'Callora-র ১১ সংখ্যার Virtual ID কেন সাধারণ ফোন নম্বরের চেয়ে বেশি নিরাপদ?' },
    { icon: <Zap className="w-3.5 h-3.5" />, label: 'WebRTC কীভাবে কাজ করে?', prompt: 'How does WebRTC enable peer-to-peer audio and video calling without lag?' }
  ];

  return (
    <div className="flex-1 flex flex-col h-full bg-[#050817] select-none">
      {/* Header */}
      <div className="h-16 px-6 bg-[#090e24]/90 border-b border-slate-800/80 backdrop-blur-xl flex items-center justify-between z-20">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-purple-500 via-indigo-600 to-cyan-400 p-0.5 shadow-lg shadow-purple-500/25">
            <div className="w-full h-full bg-[#080d22] rounded-[14px] flex items-center justify-center">
              <Bot className="w-5 h-5 text-cyan-300" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-white">Callora AI Assistant</h2>
              <span className="px-2 py-0.5 rounded-full bg-purple-950/60 border border-purple-500/30 text-purple-300 text-[10px] font-semibold">
                Gemini 2.5
              </span>
            </div>
            <p className="text-[11px] text-slate-400">দ্বিভাষিক (বাংলা ও ইংরেজি) কৃত্রিম বুদ্ধিমত্তা সহায়ক</p>
          </div>
        </div>

        <button
          onClick={() => setMessages(messages.slice(0, 1))}
          className="p-2 rounded-xl bg-slate-800/60 hover:bg-slate-700/80 text-slate-400 hover:text-rose-300 border border-slate-700 text-xs flex items-center gap-1.5 transition-colors"
          title="Clear Conversation"
        >
          <Trash2 className="w-4 h-4" />
          <span className="hidden sm:inline">নতুন আলাপ</span>
        </button>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';

          return (
            <div
              key={msg.id}
              className={`flex gap-3 max-w-[90%] sm:max-w-[78%] ${isUser ? 'ml-auto flex-row-reverse' : ''}`}
            >
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 text-xs font-bold ${
                  isUser
                    ? 'bg-gradient-to-br from-cyan-500 to-blue-600 text-white'
                    : 'bg-gradient-to-br from-purple-600 to-indigo-600 text-white shadow-md'
                }`}
              >
                {isUser ? 'You' : <Bot className="w-4 h-4 text-cyan-300" />}
              </div>

              <div
                className={`relative p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                  isUser
                    ? 'bg-gradient-to-r from-[#603bda] to-[#7f39f8] text-white rounded-tr-none'
                    : 'bg-[#0f1636] text-slate-100 rounded-tl-none border border-slate-800 shadow-xl'
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.content}</div>

                {!isUser && (
                  <div className="mt-3 pt-2 border-t border-white/10 flex items-center justify-between text-[10px] text-slate-400">
                    <span className="flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-cyan-400" />
                      <span>Callora AI Intelligence</span>
                    </span>
                    <button
                      onClick={() => handleCopy(msg.id, msg.content)}
                      className="p-1 hover:text-white flex items-center gap-1"
                      title="Copy response"
                    >
                      {copiedId === msg.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                      <span>{copiedId === msg.id ? 'কপি হয়েছে' : 'কপি'}</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {loading && (
          <div className="flex gap-3 max-w-[80%]">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-purple-600 to-indigo-600 flex items-center justify-center text-white shrink-0 animate-pulse">
              <Bot className="w-4 h-4 text-cyan-300" />
            </div>
            <div className="p-4 rounded-2xl rounded-tl-none bg-[#0f1636] border border-slate-800 flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce" />
              <div className="w-2 h-2 rounded-full bg-purple-400 animate-bounce" style={{ animationDelay: '0.2s' }} />
              <div className="w-2 h-2 rounded-full bg-fuchsia-400 animate-bounce" style={{ animationDelay: '0.4s' }} />
              <span className="text-xs text-slate-400 ml-2 font-mono">উত্তর তৈরি হচ্ছে...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Prompts */}
      <div className="px-4 py-2 bg-[#090e24]/80 border-t border-slate-800/40 flex items-center gap-2 overflow-x-auto no-scrollbar">
        {quickPrompts.map((qp, i) => (
          <button
            key={i}
            onClick={() => handleSend(qp.prompt)}
            className="whitespace-nowrap shrink-0 px-3 py-1.5 rounded-xl bg-[#101735] hover:bg-purple-950/80 border border-slate-800 hover:border-purple-500/40 text-slate-300 hover:text-white text-xs flex items-center gap-1.5 transition-all active:scale-95"
          >
            {qp.icon}
            <span>{qp.label}</span>
          </button>
        ))}
      </div>

      {/* Input Bar */}
      <div className="p-3 sm:p-4 bg-[#090e24] border-t border-slate-800/80">
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleSend();
            }}
            placeholder="বাংলা বা ইংরেজিতে যা খুশি জিজ্ঞাসা করুন..."
            className="flex-1 py-3 px-4 bg-[#111735] border border-slate-700/80 rounded-2xl text-white placeholder-slate-500 text-sm focus:outline-none focus:border-purple-400 transition-colors"
          />
          <button
            onClick={() => handleSend()}
            disabled={!inputText.trim() || loading}
            className="p-3 rounded-2xl bg-gradient-to-r from-purple-500 via-indigo-600 to-cyan-500 hover:from-purple-400 hover:to-cyan-400 text-white font-bold shadow-lg shadow-purple-500/25 transition-all transform active:scale-95 disabled:opacity-40"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
