import React, { useEffect, useRef, useState } from 'react';
import {
  Mic,
  MicOff,
  Video as VideoIcon,
  VideoOff,
  PhoneOff,
  ScreenShare,
  Minimize2,
  Maximize2,
  Volume2,
  Shield,
  Sparkles,
  PhoneCall,
  PhoneIncoming,
  Check
} from 'lucide-react';
import { UserProfile, CallSession } from '../types';
import { getInitials } from '../services/firebase';
import { sound } from '../services/sound';

interface CallModalProps {
  currentUser: UserProfile;
  activeCall: CallSession | null;
  incomingCall: CallSession | null;
  onAcceptIncoming: (type: 'audio' | 'video') => void;
  onDeclineIncoming: () => void;
  onEndCall: () => void;
}

const RTC_CONFIG: RTCConfiguration = {
  iceServers: [
    { urls: 'stun:stun.l.google.com:19302' },
    { urls: 'stun:stun1.l.google.com:19302' },
    { urls: 'stun:stun2.l.google.com:19302' }
  ]
};

export const CallModal: React.FC<CallModalProps> = ({
  currentUser,
  activeCall,
  incomingCall,
  onAcceptIncoming,
  onDeclineIncoming,
  onEndCall
}) => {
  const [isMuted, setIsMuted] = useState(false);
  const [isVideoOff, setIsVideoOff] = useState(false);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [connectionState, setConnectionState] = useState<'connecting' | 'connected' | 'reconnecting'>('connecting');

  const localVideoRef = useRef<HTMLVideoElement | null>(null);
  const remoteVideoRef = useRef<HTMLVideoElement | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const peerConnRef = useRef<RTCPeerConnection | null>(null);
  const durationTimerRef = useRef<number | null>(null);

  // Incoming call ringtone management
  useEffect(() => {
    if (incomingCall && !activeCall) {
      sound.startIncomingRingtone();
    } else if (activeCall && activeCall.status === 'calling') {
      sound.startOutgoingDialing();
    } else {
      sound.stopRingtone();
    }
    return () => {
      sound.stopRingtone();
    };
  }, [incomingCall, activeCall]);

  // Handle active call connection and media stream initialization
  useEffect(() => {
    if (!activeCall) {
      if (localStreamRef.current) {
        localStreamRef.current.getTracks().forEach(track => track.stop());
        localStreamRef.current = null;
      }
      if (peerConnRef.current) {
        peerConnRef.current.close();
        peerConnRef.current = null;
      }
      if (durationTimerRef.current) {
        clearInterval(durationTimerRef.current);
        durationTimerRef.current = null;
      }
      setCallDuration(0);
      return;
    }

    let isSubscribed = true;

    async function initMediaAndWebRTC() {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: true,
          video: activeCall?.type === 'video'
        });

        if (!isSubscribed) {
          stream.getTracks().forEach(t => t.stop());
          return;
        }

        localStreamRef.current = stream;
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }

        // Set up Peer Connection
        const pc = new RTCPeerConnection(RTC_CONFIG);
        peerConnRef.current = pc;

        stream.getTracks().forEach(track => {
          pc.addTrack(track, stream);
        });

        pc.ontrack = (event) => {
          if (remoteVideoRef.current && event.streams[0]) {
            remoteVideoRef.current.srcObject = event.streams[0];
          }
        };

        pc.onconnectionstatechange = () => {
          if (pc.connectionState === 'connected') {
            setConnectionState('connected');
            sound.playCallConnected();
          } else if (pc.connectionState === 'disconnected' || pc.connectionState === 'failed') {
            setConnectionState('reconnecting');
          }
        };

        // Simulate fast connection timer for realistic interactive testing
        const connectTimeout = setTimeout(() => {
          if (isSubscribed) {
            setConnectionState('connected');
            sound.playCallConnected();
            durationTimerRef.current = window.setInterval(() => {
              setCallDuration(prev => prev + 1);
            }, 1000);
          }
        }, 1800);

        return () => clearTimeout(connectTimeout);
      } catch (err) {
        console.warn('getUserMedia error (device might lack camera or mic in iframe):', err);
        // Fallback: Still allow simulation of connected state
        setConnectionState('connected');
        sound.playCallConnected();
        durationTimerRef.current = window.setInterval(() => {
          setCallDuration(prev => prev + 1);
        }, 1000);
      }
    }

    initMediaAndWebRTC();

    return () => {
      isSubscribed = false;
      if (durationTimerRef.current) {
        clearInterval(durationTimerRef.current);
      }
    };
  }, [activeCall]);

  const toggleMute = () => {
    if (localStreamRef.current) {
      const audioTrack = localStreamRef.current.getAudioTracks()[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack.enabled;
        setIsMuted(!audioTrack.enabled);
      }
    } else {
      setIsMuted(!isMuted);
    }
  };

  const toggleVideo = async () => {
    if (localStreamRef.current) {
      const videoTrack = localStreamRef.current.getVideoTracks()[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack.enabled;
        setIsVideoOff(!videoTrack.enabled);
      } else {
        // Switch audio call to video
        try {
          const videoStream = await navigator.mediaDevices.getUserMedia({ video: true });
          const newVideoTrack = videoStream.getVideoTracks()[0];
          localStreamRef.current.addTrack(newVideoTrack);
          if (peerConnRef.current) {
            peerConnRef.current.addTrack(newVideoTrack, localStreamRef.current);
          }
          if (localVideoRef.current) {
            localVideoRef.current.srcObject = localStreamRef.current;
          }
          setIsVideoOff(false);
        } catch (e) {
          console.warn('Could not add video track:', e);
        }
      }
    } else {
      setIsVideoOff(!isVideoOff);
    }
  };

  const toggleScreenShare = async () => {
    if (!isScreenSharing) {
      try {
        const screenStream = await navigator.mediaDevices.getDisplayMedia({ video: true });
        const screenTrack = screenStream.getVideoTracks()[0];

        if (peerConnRef.current && localStreamRef.current) {
          const sender = peerConnRef.current.getSenders().find(s => s.track?.kind === 'video');
          if (sender) {
            sender.replaceTrack(screenTrack);
          }
        }
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = screenStream;
        }
        setIsScreenSharing(true);

        screenTrack.onended = () => {
          setIsScreenSharing(false);
          if (localStreamRef.current && localVideoRef.current) {
            localVideoRef.current.srcObject = localStreamRef.current;
          }
        };
      } catch (err) {
        console.warn('Screen share cancelled or unsupported:', err);
      }
    } else {
      setIsScreenSharing(false);
      if (localStreamRef.current && localVideoRef.current) {
        localVideoRef.current.srcObject = localStreamRef.current;
      }
    }
  };

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  // 1. INCOMING CALL POPUP
  if (incomingCall && !activeCall) {
    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl animate-in fade-in">
        <div className="relative w-full max-w-sm bg-gradient-to-b from-[#111938] to-[#070b1e] border border-cyan-500/40 rounded-3xl p-6 text-center shadow-[0_0_90px_rgba(0,217,255,0.3)]">
          {/* Animated pulse rings */}
          <div className="relative mx-auto w-24 h-24 mb-4 flex items-center justify-center">
            <div className="absolute inset-0 rounded-full bg-cyan-400/20 animate-pulse-ring" />
            <div className="absolute -inset-3 rounded-full bg-fuchsia-500/20 animate-pulse-ring" style={{ animationDelay: '0.6s' }} />
            
            {incomingCall.callerAvatar ? (
              <img
                src={incomingCall.callerAvatar}
                alt={incomingCall.callerName}
                className="w-24 h-24 rounded-full object-cover ring-4 ring-cyan-400 relative z-10 shadow-xl"
              />
            ) : (
              <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-3xl font-black text-white ring-4 ring-cyan-400 relative z-10 shadow-xl">
                {getInitials(incomingCall.callerName)}
              </div>
            )}
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/70 border border-cyan-400/40 text-cyan-300 text-xs font-semibold uppercase tracking-wider mb-2 animate-bounce">
            <PhoneIncoming className="w-3.5 h-3.5" />
            <span>ইনকামিং {incomingCall.type === 'video' ? 'ভিডিও' : 'অডিও'} কল</span>
          </div>

          <h3 className="text-xl font-bold text-white mb-1">{incomingCall.callerName}</h3>
          <p className="text-xs text-cyan-300 font-mono mb-6">ID: {incomingCall.callerVirtualId || '210XXXXXXXX'}</p>

          {/* Action Buttons */}
          <div className="flex items-center justify-center gap-6">
            <button
              onClick={onDeclineIncoming}
              className="flex flex-col items-center gap-1.5 text-xs text-rose-300 group"
            >
              <div className="w-14 h-14 rounded-full bg-rose-600 group-hover:bg-rose-500 text-white flex items-center justify-center shadow-lg shadow-rose-600/30 transition-all transform active:scale-90">
                <PhoneOff className="w-6 h-6" />
              </div>
              <span className="font-semibold">Decline</span>
            </button>

            <button
              onClick={() => onAcceptIncoming(incomingCall.type)}
              className="flex flex-col items-center gap-1.5 text-xs text-emerald-300 group"
            >
              <div className="w-14 h-14 rounded-full bg-gradient-to-r from-emerald-500 to-teal-500 group-hover:from-emerald-400 group-hover:to-teal-400 text-white flex items-center justify-center shadow-lg shadow-emerald-500/40 transition-all transform active:scale-90 animate-pulse">
                {incomingCall.type === 'video' ? <VideoIcon className="w-6 h-6" /> : <PhoneCall className="w-6 h-6" />}
              </div>
              <span className="font-semibold">Accept</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  // 2. ACTIVE CALL (Minimized PiP Mode)
  if (activeCall && isMinimized) {
    const isCaller = activeCall.callerId === currentUser.uid;
    const remoteName = isCaller ? activeCall.receiverName : activeCall.callerName;
    const remoteAvatar = isCaller ? activeCall.receiverAvatar : activeCall.callerAvatar;

    return (
      <div className="fixed bottom-6 right-6 z-50 bg-[#090e24]/95 border border-cyan-500/40 backdrop-blur-xl rounded-2xl p-3 shadow-[0_10px_40px_rgba(0,0,0,0.7)] flex items-center gap-3 animate-in slide-in-from-bottom-5">
        <div className="relative">
          {remoteAvatar ? (
            <img src={remoteAvatar} alt={remoteName} className="w-10 h-10 rounded-full object-cover ring-2 ring-cyan-400" />
          ) : (
            <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-sm font-bold text-white ring-2 ring-cyan-400">
              {getInitials(remoteName)}
            </div>
          )}
          <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full ring-2 ring-[#090e24] animate-ping" />
        </div>

        <div>
          <div className="text-xs font-bold text-white flex items-center gap-1.5">
            <span className="truncate max-w-[120px]">{remoteName}</span>
            <span className="text-[10px] text-cyan-400 font-mono">({formatTimer(callDuration)})</span>
          </div>
          <span className="text-[10px] text-slate-400 flex items-center gap-1">
            <Sparkles className="w-2.5 h-2.5 text-cyan-400" />
            <span>HD {activeCall.type} Call</span>
          </span>
        </div>

        <div className="flex items-center gap-1.5 ml-2">
          <button
            onClick={() => setIsMinimized(false)}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200"
            title="Maximize call screen"
          >
            <Maximize2 className="w-4 h-4" />
          </button>
          <button
            onClick={onEndCall}
            className="p-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white"
            title="End Call"
          >
            <PhoneOff className="w-4 h-4" />
          </button>
        </div>
      </div>
    );
  }

  // 3. ACTIVE CALL (Full Screen View)
  if (activeCall && !isMinimized) {
    const isCaller = activeCall.callerId === currentUser.uid;
    const remoteName = isCaller ? activeCall.receiverName : activeCall.callerName;
    const remoteAvatar = isCaller ? activeCall.receiverAvatar : activeCall.callerAvatar;

    return (
      <div className="fixed inset-0 z-50 flex flex-col bg-[#030612] text-white select-none">
        {/* Top Header Bar */}
        <div className="relative z-20 flex items-center justify-between px-6 py-4 bg-gradient-to-b from-black/80 via-black/40 to-transparent">
          <div className="flex items-center gap-3">
            <div className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm sm:text-base text-white">{remoteName}</span>
                <span className="px-2 py-0.5 rounded-full bg-cyan-950/60 border border-cyan-500/30 text-cyan-300 text-[10px] font-semibold uppercase tracking-wider">
                  {activeCall.type === 'video' ? '📹 HD Video' : '📞 Crystal Audio'}
                </span>
              </div>
              <p className="text-xs text-slate-400 flex items-center gap-1.5 mt-0.5">
                <Shield className="w-3 h-3 text-cyan-400" />
                <span>End-to-End Encrypted Peer Connection</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-3 py-1 rounded-full bg-slate-900/80 border border-slate-700/60 text-xs font-mono text-cyan-300 font-bold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
              {connectionState === 'connected' ? formatTimer(callDuration) : 'Connecting...'}
            </div>

            <button
              onClick={() => setIsMinimized(true)}
              className="p-2.5 rounded-xl bg-slate-900/70 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/50 transition-colors"
              title="Minimize to Picture-in-Picture"
            >
              <Minimize2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Video / Audio Canvas Body */}
        <div className="relative flex-1 flex items-center justify-center overflow-hidden bg-gradient-to-b from-[#060a1d] to-[#02040c]">
          {/* Background animated ambiance */}
          <div className="absolute w-[600px] h-[600px] bg-gradient-to-tr from-cyan-500/10 via-indigo-600/10 to-purple-600/10 rounded-full blur-3xl pointer-events-none" />

          {/* Remote Video Stream or Avatar waveform */}
          {activeCall.type === 'video' ? (
            <div className="relative w-full h-full flex items-center justify-center">
              <video
                ref={remoteVideoRef}
                autoPlay
                playsInline
                className="w-full h-full object-cover"
              />
              {/* Fallback if remote video track is not sending */}
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 backdrop-blur-sm pointer-events-none">
                <div className="relative flex items-center justify-center mb-4">
                  <div className="absolute -inset-4 rounded-full bg-cyan-400/20 animate-pulse-ring" />
                  {remoteAvatar ? (
                    <img src={remoteAvatar} alt={remoteName} className="w-28 h-28 rounded-full object-cover ring-4 ring-cyan-400/60 shadow-2xl" />
                  ) : (
                    <div className="w-28 h-28 rounded-full bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-4xl font-black text-white ring-4 ring-cyan-400/60 shadow-2xl">
                      {getInitials(remoteName)}
                    </div>
                  )}
                </div>
                <h4 className="text-xl font-bold text-white">{remoteName}</h4>
                <p className="text-xs text-slate-300 mt-1">
                  {connectionState === 'connected' ? '🟢 HD Stream Active' : '🟡 Connecting stream...'}
                </p>
              </div>
            </div>
          ) : (
            /* Audio Call Visualizer */
            <div className="relative flex flex-col items-center justify-center z-10">
              <div className="relative mb-6">
                <div className="absolute -inset-6 rounded-full bg-gradient-to-r from-cyan-500/30 to-fuchsia-500/30 animate-pulse-ring" />
                <div className="absolute -inset-12 rounded-full bg-cyan-400/15 animate-pulse-ring" style={{ animationDelay: '0.8s' }} />

                {remoteAvatar ? (
                  <img
                    src={remoteAvatar}
                    alt={remoteName}
                    className="w-32 h-32 rounded-full object-cover ring-4 ring-cyan-400 relative z-10 shadow-[0_0_50px_rgba(0,217,255,0.4)]"
                  />
                ) : (
                  <div className="w-32 h-32 rounded-full bg-gradient-to-tr from-cyan-500 via-indigo-600 to-purple-600 flex items-center justify-center text-5xl font-black text-white ring-4 ring-cyan-400 relative z-10 shadow-[0_0_50px_rgba(0,217,255,0.4)]">
                    {getInitials(remoteName)}
                  </div>
                )}
              </div>

              <h3 className="text-2xl font-bold text-white mb-1">{remoteName}</h3>
              <p className="text-sm text-cyan-300 font-medium mb-5">
                {connectionState === 'connected' ? 'Speaking on Callora Voice' : 'Connecting HD Audio...'}
              </p>

              {/* Animated Audio Equalizer Bars */}
              <div className="flex items-center gap-1.5 h-8 px-4 py-2 rounded-full bg-slate-900/60 border border-slate-700/60">
                <div className="w-1 bg-cyan-400 rounded-full wave-bar-1" />
                <div className="w-1 bg-cyan-300 rounded-full wave-bar-2" />
                <div className="w-1 bg-fuchsia-400 rounded-full wave-bar-3" />
                <div className="w-1 bg-purple-400 rounded-full wave-bar-4" />
                <div className="w-1 bg-indigo-400 rounded-full wave-bar-5" />
                <div className="w-1 bg-cyan-400 rounded-full wave-bar-2" />
                <div className="w-1 bg-emerald-400 rounded-full wave-bar-3" />
              </div>
            </div>
          )}

          {/* Local User Video PiP Preview */}
          <div className="absolute top-20 right-6 z-30 w-36 h-48 sm:w-44 sm:h-56 rounded-2xl overflow-hidden border-2 border-white/20 bg-slate-900 shadow-2xl group transition-transform hover:scale-105">
            <video
              ref={localVideoRef}
              autoPlay
              muted
              playsInline
              className={`w-full h-full object-cover ${isVideoOff ? 'hidden' : 'block'}`}
            />
            {isVideoOff && (
              <div className="w-full h-full flex flex-col items-center justify-center bg-slate-900 p-2 text-center">
                <div className="w-12 h-12 rounded-full bg-indigo-600 flex items-center justify-center text-lg font-bold text-white mb-1">
                  {getInitials(currentUser.name)}
                </div>
                <span className="text-[10px] text-slate-400">Camera Off</span>
              </div>
            )}
            <div className="absolute bottom-2 left-2 px-2 py-0.5 rounded-md bg-black/60 backdrop-blur-md text-[10px] text-white font-medium">
              You {isMuted && '🔇'}
            </div>
          </div>
        </div>

        {/* Bottom Call Control Floating Bar */}
        <div className="relative z-20 px-6 py-6 bg-gradient-to-t from-black via-black/80 to-transparent flex items-center justify-center">
          <div className="flex items-center gap-3 sm:gap-4 p-3 rounded-3xl bg-[#101733]/90 border border-white/10 backdrop-blur-2xl shadow-[0_10px_50px_rgba(0,0,0,0.8)]">
            {/* Mic Toggle */}
            <button
              onClick={toggleMute}
              className={`p-4 rounded-2xl font-bold transition-all transform active:scale-95 flex items-center justify-center ${
                isMuted
                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40 hover:bg-rose-500/30'
                  : 'bg-slate-800/80 hover:bg-slate-700 text-white border border-slate-700'
              }`}
              title={isMuted ? 'Unmute Mic' : 'Mute Mic'}
            >
              {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            {/* Video Toggle */}
            <button
              onClick={toggleVideo}
              className={`p-4 rounded-2xl font-bold transition-all transform active:scale-95 flex items-center justify-center ${
                isVideoOff
                  ? 'bg-rose-500/20 text-rose-400 border border-rose-500/40 hover:bg-rose-500/30'
                  : 'bg-slate-800/80 hover:bg-slate-700 text-white border border-slate-700'
              }`}
              title={isVideoOff ? 'Turn Video On' : 'Turn Video Off'}
            >
              {isVideoOff ? <VideoOff className="w-5 h-5" /> : <VideoIcon className="w-5 h-5" />}
            </button>

            {/* Screen Share */}
            <button
              onClick={toggleScreenShare}
              className={`p-4 rounded-2xl font-bold transition-all transform active:scale-95 hidden sm:flex items-center justify-center ${
                isScreenSharing
                  ? 'bg-cyan-500 text-slate-950 shadow-lg shadow-cyan-500/40'
                  : 'bg-slate-800/80 hover:bg-slate-700 text-white border border-slate-700'
              }`}
              title="Share Screen"
            >
              <ScreenShare className="w-5 h-5" />
            </button>

            {/* End Call Button */}
            <button
              onClick={onEndCall}
              className="px-6 py-4 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold flex items-center gap-2 shadow-lg shadow-rose-600/40 transition-all transform active:scale-95"
              title="End Call"
            >
              <PhoneOff className="w-5 h-5" />
              <span className="hidden sm:inline">End Call</span>
            </button>
          </div>
        </div>
      </div>
    );
  }

  return null;
};
