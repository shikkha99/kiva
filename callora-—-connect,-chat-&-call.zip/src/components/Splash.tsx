import React from 'react';
import { Sparkles, MessageCircle, PhoneCall } from 'lucide-react';

interface SplashProps {
  onComplete?: () => void;
}

export const Splash: React.FC<SplashProps> = () => {
  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#050817] overflow-hidden select-none">
      {/* Background ambient radial glow */}
      <div className="absolute w-[500px] h-[500px] bg-gradient-to-tr from-cyan-500/20 via-indigo-600/25 to-fuchsia-600/20 rounded-full blur-3xl pointer-events-none animate-pulse" />
      <div className="absolute top-1/4 -right-20 w-80 h-80 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-fuchsia-500/15 rounded-full blur-3xl pointer-events-none" />

      {/* Main Logo Container */}
      <div className="relative z-10 flex flex-col items-center">
        <div className="relative flex items-center justify-center w-28 h-28 rounded-3xl bg-gradient-to-br from-[#00d9ff] via-[#7c3cff] to-[#ec45ff] p-0.5 shadow-[0_0_70px_rgba(124,60,255,0.6)] animate-float">
          <div className="w-full h-full bg-[#090e24]/90 rounded-[22px] flex items-center justify-center relative overflow-hidden backdrop-blur-md">
            <div className="absolute inset-0 bg-gradient-to-br from-cyan-400/20 to-purple-600/20" />
            <div className="relative flex items-center justify-center">
              <MessageCircle className="w-12 h-12 text-cyan-300 transform -translate-x-1 -translate-y-1" />
              <PhoneCall className="w-8 h-8 text-fuchsia-400 absolute transform translate-x-2 translate-y-2 stroke-[2.5]" />
            </div>
          </div>
          {/* Pulsing ring */}
          <div className="absolute -inset-2 rounded-3xl bg-gradient-to-r from-cyan-400 to-fuchsia-500 opacity-40 blur-sm -z-10 animate-pulse" />
        </div>

        {/* Title */}
        <h1 className="mt-6 text-4xl sm:text-5xl font-extrabold tracking-tight gradient-text-callora">
          Callora
        </h1>

        {/* Bengali + English Subtitle */}
        <p className="mt-2 text-sm sm:text-base font-medium text-slate-400 flex items-center gap-2">
          <span>Connect</span>
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
          <span>Chat</span>
          <span className="w-1.5 h-1.5 rounded-full bg-purple-400" />
          <span>Call</span>
        </p>

        <p className="mt-1 text-xs text-slate-500">
          ভার্চুয়াল আইডিতে নিরাপদ ও আধুনিক যোগাযোগ
        </p>

        {/* Loader bar */}
        <div className="mt-8 w-56 h-1.5 bg-[#151c36] rounded-full overflow-hidden p-0.5 border border-white/5 shadow-inner">
          <div className="h-full w-2/5 bg-gradient-to-r from-cyan-400 via-indigo-500 to-fuchsia-500 rounded-full animate-[load_1.5s_infinite_ease-in-out]" />
        </div>

        <div className="mt-4 flex items-center gap-1.5 text-xs text-slate-500">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-spin" />
          <span>Starting secure WebRTC engine...</span>
        </div>
      </div>

      <style>{`
        @keyframes load {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(280%); }
        }
      `}</style>
    </div>
  );
};
