import React, { useState } from 'react';
import { X, Copy, Check, QrCode, Shield, Sparkles, Share2, Smartphone } from 'lucide-react';
import { UserProfile } from '../types';
import { formatVirtualId, getInitials } from '../services/firebase';
import confetti from 'canvas-confetti';

interface VirtualIdCardModalProps {
  user: UserProfile;
  isOpen: boolean;
  onClose: () => void;
}

export const VirtualIdCardModal: React.FC<VirtualIdCardModalProps> = ({ user, isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!isOpen) return null;

  const handleCopyId = async () => {
    try {
      await navigator.clipboard.writeText(user.virtualId);
      setCopied(true);
      confetti({ particleCount: 40, spread: 60, origin: { y: 0.7 } });
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // fallback
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    }
  };

  const handleCopyLink = async () => {
    const link = `${window.location.origin}/#${user.virtualId}`;
    try {
      await navigator.clipboard.writeText(link);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-[#0c1228] border border-cyan-500/30 rounded-3xl p-6 shadow-[0_0_80px_rgba(0,217,255,0.2)] overflow-hidden">
        {/* Decorative background gradients */}
        <div className="absolute -top-24 -right-24 w-60 h-60 bg-gradient-to-br from-cyan-500/20 to-purple-600/30 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -left-20 w-60 h-60 bg-gradient-to-tr from-fuchsia-500/20 to-blue-600/30 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 text-slate-400 hover:text-white bg-slate-800/50 hover:bg-slate-700/60 rounded-full transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/60 border border-cyan-500/30 text-cyan-400 text-xs font-semibold uppercase tracking-wider mb-2">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Official Callora Identity</span>
          </div>
          <h2 className="text-2xl font-bold text-white">ভার্চুয়াল আইডি কার্ড</h2>
          <p className="text-xs text-slate-400 mt-0.5">ফোন নম্বর ছাড়াই যে কেউ আপনাকে সহজে খুঁজে পাবে</p>
        </div>

        {/* Holographic Virtual ID Card */}
        <div className="relative rounded-2xl p-5 bg-gradient-to-br from-[#121938] via-[#0e152f] to-[#1a1c3d] border border-white/15 shadow-2xl overflow-hidden mb-6 group hover:border-cyan-400/50 transition-all duration-300">
          {/* Card Chip & Network Logo */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <div className="w-10 h-7 rounded-md bg-gradient-to-tr from-amber-300 via-amber-400 to-yellow-600 p-0.5 shadow-md flex items-center justify-center">
                <div className="w-full h-full border border-amber-900/40 rounded flex flex-col justify-around py-0.5 px-1">
                  <div className="w-full h-[1px] bg-amber-900/50" />
                  <div className="w-full h-[1px] bg-amber-900/50" />
                </div>
              </div>
              <span className="text-[11px] font-bold tracking-widest text-slate-400 uppercase">CALLORA PASS</span>
            </div>

            <div className="flex items-center gap-1 text-cyan-400 text-xs font-bold bg-cyan-950/40 px-2.5 py-1 rounded-full border border-cyan-500/20">
              <Shield className="w-3.5 h-3.5 text-cyan-400" />
              <span>VERIFIED ID</span>
            </div>
          </div>

          {/* User Info & Avatar */}
          <div className="flex items-center gap-4 mb-5">
            {user.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.name}
                className="w-16 h-16 rounded-2xl object-cover ring-2 ring-cyan-400/50 shadow-lg"
              />
            ) : (
              <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${user.avatarBg || 'from-cyan-500 to-indigo-600'} flex items-center justify-center text-2xl font-black text-white ring-2 ring-cyan-400/50 shadow-lg`}>
                {getInitials(user.name)}
              </div>
            )}

            <div className="flex-1 min-w-0">
              <h3 className="text-lg font-bold text-white truncate">{user.name}</h3>
              <p className="text-xs text-cyan-300 font-mono">@{user.username || 'user'}</p>
              <p className="text-[11px] text-slate-400 truncate mt-0.5">{user.statusText || 'Available on Callora'}</p>
            </div>
          </div>

          {/* Large 11-digit Virtual ID Display */}
          <div className="bg-[#080d22]/90 border border-cyan-500/30 rounded-xl p-3.5 flex items-center justify-between">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block mb-0.5">
                VIRTUAL ID (১১ সংখ্যা)
              </span>
              <span className="text-xl sm:text-2xl font-black font-mono tracking-wider text-cyan-300">
                {formatVirtualId(user.virtualId)}
              </span>
            </div>

            <button
              onClick={handleCopyId}
              className={`p-2.5 rounded-xl transition-all font-semibold text-xs flex items-center gap-1.5 ${
                copied
                  ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30'
                  : 'bg-cyan-500/20 hover:bg-cyan-500 text-cyan-300 hover:text-slate-950 border border-cyan-400/30'
              }`}
              title="Copy Virtual ID"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'কপি হয়েছে' : 'কপি'}</span>
            </button>
          </div>

          {/* Bottom Card Footer */}
          <div className="mt-3.5 flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-white/5">
            <span className="flex items-center gap-1">
              <Smartphone className="w-3.5 h-3.5 text-slate-400" />
              <span>Direct Chat & HD Calls</span>
            </span>
            <span className="text-emerald-400 font-medium">● Lifetime Active</span>
          </div>
        </div>

        {/* QR Code & Share Action Buttons */}
        <div className="space-y-3">
          <div className="flex gap-2">
            <button
              onClick={handleCopyId}
              className="flex-1 py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25 transition-all transform active:scale-95"
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'আইডি কপি সম্পন্ন!' : 'Virtual ID কপি করুন'}</span>
            </button>

            <button
              onClick={handleCopyLink}
              className="py-3 px-4 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 hover:text-white border border-slate-700 font-semibold text-sm flex items-center justify-center gap-2 transition-all active:scale-95"
              title="Copy direct invite link"
            >
              {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
              <span className="hidden sm:inline">{copiedLink ? 'লিঙ্ক কপি হয়েছে' : 'লিঙ্ক শেয়ার'}</span>
            </button>
          </div>

          <div className="p-3 bg-[#0a0f26] border border-slate-800 rounded-xl flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-white p-1 flex items-center justify-center shrink-0">
              <QrCode className="w-8 h-8 text-slate-900" />
            </div>
            <div className="flex-1 text-xs">
              <p className="font-semibold text-slate-200">কীভাবে ব্যবহার করবেন?</p>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                বন্ধুরা তাদের Callora সার্চ বারে আপনার <span className="text-cyan-300 font-mono">{user.virtualId}</span> নম্বরটি দিলে সরাসরি আপনার সাথে চ্যাট ও ভিডিও কল শুরু করতে পারবে।
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
