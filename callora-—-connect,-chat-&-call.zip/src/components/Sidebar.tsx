import React, { useState } from 'react';
import {
  MessageSquare,
  Users,
  Bot,
  Settings,
  Search,
  Copy,
  Check,
  LogOut,
  Sparkles,
  QrCode,
  MessagesSquare,
  UserPlus
} from 'lucide-react';
import { UserProfile, ActiveTab } from '../types';
import { formatVirtualId, getInitials, formatTimestamp } from '../services/firebase';

interface SidebarProps {
  currentUser: UserProfile;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  selectedChatUser: UserProfile | null;
  onSelectChatUser: (user: UserProfile) => void;
  recentUsers: UserProfile[];
  onOpenIdCard: () => void;
  onSearchVirtualId: (query: string) => void;
  searchResult: UserProfile | null;
  searchError: string | null;
  onLogout: () => void;
  onAddContactDirect?: (user: UserProfile) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentUser,
  activeTab,
  setActiveTab,
  selectedChatUser,
  onSelectChatUser,
  recentUsers,
  onOpenIdCard,
  onSearchVirtualId,
  searchResult,
  searchError,
  onLogout,
  onAddContactDirect
}) => {
  const [searchInput, setSearchInput] = useState('');
  const [copiedId, setCopiedId] = useState(false);

  const handleCopyId = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(currentUser.virtualId);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      onSearchVirtualId(searchInput.trim());
    }
  };

  return (
    <aside className="w-full md:w-80 lg:w-96 h-full flex flex-col bg-[#080d22] border-r border-slate-800/80 select-none">
      {/* Brand Header */}
      <div className="p-4 border-b border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#00d9ff] via-[#7544ff] to-[#ec45ff] p-0.5 shadow-[0_0_20px_rgba(0,217,255,0.3)]">
            <div className="w-full h-full bg-[#090e24] rounded-[14px] flex items-center justify-center">
              <MessageSquare className="w-5 h-5 text-cyan-400" />
            </div>
          </div>
          <div>
            <h1 className="text-xl font-black tracking-tight gradient-text-callora leading-none">
              Callora
            </h1>
            <span className="text-[10px] font-medium text-slate-400 tracking-wide block mt-0.5">
              Connect • Chat • Call
            </span>
          </div>
        </div>

        <button
          onClick={onOpenIdCard}
          className="p-2 rounded-xl bg-slate-800/60 hover:bg-slate-700/80 text-cyan-300 hover:text-white border border-cyan-500/20 text-xs flex items-center gap-1.5 transition-colors cursor-pointer"
          title="View Virtual ID Pass"
        >
          <QrCode className="w-4 h-4" />
          <span className="hidden sm:inline font-bold">ID কার্ড</span>
        </button>
      </div>

      {/* Current User Quick Badge */}
      <div className="p-3 mx-3 mt-3 rounded-2xl bg-gradient-to-r from-[#101735] to-[#0d142f] border border-cyan-500/20 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="relative shrink-0">
            {currentUser.photoURL ? (
              <img
                src={currentUser.photoURL}
                alt={currentUser.name}
                className="w-11 h-11 rounded-xl object-cover ring-2 ring-cyan-400/40"
              />
            ) : (
              <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${currentUser.avatarBg || 'from-cyan-500 to-indigo-600'} flex items-center justify-center text-sm font-bold text-white ring-2 ring-cyan-400/40`}>
                {getInitials(currentUser.name)}
              </div>
            )}
            <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-500 ring-2 ring-[#080d22]" />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white truncate">{currentUser.name}</h3>
              <span className="text-[10px] text-emerald-400 font-medium">Online</span>
            </div>

            <div
              onClick={handleCopyId}
              className="inline-flex items-center gap-1.5 mt-0.5 px-2 py-0.5 rounded-md bg-cyan-950/60 border border-cyan-500/30 text-cyan-300 hover:text-cyan-200 text-xs font-mono cursor-pointer transition-colors"
              title="Click to copy Virtual ID"
            >
              <span>{formatVirtualId(currentUser.virtualId)}</span>
              {copiedId ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3 opacity-70" />}
            </div>
          </div>
        </div>
      </div>

      {/* 11-digit Virtual ID Search Box */}
      <div className="px-3 mt-3">
        <form onSubmit={handleSearchSubmit} className="relative flex items-center">
          <input
            type="text"
            value={searchInput}
            onChange={(e) => {
              const val = e.target.value;
              setSearchInput(val);
              if (val.trim().length >= 3) {
                onSearchVirtualId(val.trim());
              }
            }}
            placeholder="১১-সংখ্যার Virtual ID দিয়ে খুঁজুন..."
            className="w-full pl-9 pr-14 py-2.5 bg-[#101735] border border-slate-700/80 rounded-xl text-white placeholder-slate-500 text-xs focus:outline-none focus:border-cyan-400 transition-colors font-mono"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
          <button
            type="submit"
            className="absolute right-1.5 px-2.5 py-1 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
          >
            খুঁজুন
          </button>
        </form>

        {/* Search Result Dropdown Card */}
        {searchResult && (
          <div className="mt-2 p-3 rounded-xl bg-gradient-to-r from-cyan-950/90 to-indigo-950/90 border border-cyan-400/50 shadow-2xl animate-in fade-in">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2.5 min-w-0">
                {searchResult.photoURL ? (
                  <img src={searchResult.photoURL} alt={searchResult.name} className="w-9 h-9 rounded-lg object-cover" />
                ) : (
                  <div className={`w-9 h-9 rounded-lg bg-gradient-to-br ${searchResult.avatarBg || 'from-cyan-500 to-indigo-600'} flex items-center justify-center text-xs font-bold text-white`}>
                    {getInitials(searchResult.name)}
                  </div>
                )}
                <div className="min-w-0">
                  <p className="text-xs font-bold text-white truncate">{searchResult.name}</p>
                  <p className="text-[10px] text-cyan-300 font-mono">{formatVirtualId(searchResult.virtualId)}</p>
                </div>
              </div>

              <div className="flex items-center gap-1.5 shrink-0">
                <button
                  onClick={() => {
                    onSelectChatUser(searchResult);
                    setSearchInput('');
                  }}
                  className="px-2.5 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold flex items-center gap-1 transition-all cursor-pointer"
                >
                  <MessageSquare className="w-3.5 h-3.5" />
                  <span>চ্যাট</span>
                </button>
                {onAddContactDirect && (
                  <button
                    onClick={() => {
                      onAddContactDirect(searchResult);
                      setSearchInput('');
                    }}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 border border-slate-700 cursor-pointer"
                    title="কন্ট্যাক্টে সেভ করুন"
                  >
                    <UserPlus className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>
          </div>
        )}

        {searchError && (
          <p className="text-[11px] text-rose-400 mt-1.5 px-1">{searchError}</p>
        )}
      </div>

      {/* Navigation Tabs */}
      <div className="grid grid-cols-5 gap-1 p-2 mx-3 mt-3 rounded-2xl bg-[#0e142f] border border-slate-800">
        <button
          onClick={() => setActiveTab('chats')}
          className={`py-2 rounded-xl text-xs font-bold flex flex-col items-center gap-1 transition-all relative cursor-pointer ${
            activeTab === 'chats'
              ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
          }`}
          title="Chats"
        >
          <MessageSquare className="w-4 h-4" />
          <span className="text-[10px]">চ্যাট</span>
        </button>

        <button
          onClick={() => setActiveTab('contacts')}
          className={`py-2 rounded-xl text-xs font-bold flex flex-col items-center gap-1 transition-all cursor-pointer ${
            activeTab === 'contacts'
              ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
          }`}
          title="Contacts"
        >
          <Users className="w-4 h-4" />
          <span className="text-[10px]">কন্ট্যাক্ট</span>
        </button>

        <button
          onClick={() => setActiveTab('groups')}
          className={`py-2 rounded-xl text-xs font-bold flex flex-col items-center gap-1 transition-all cursor-pointer ${
            activeTab === 'groups'
              ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
          }`}
          title="Groups"
        >
          <MessagesSquare className="w-4 h-4" />
          <span className="text-[10px]">গ্রুপ</span>
        </button>

        <button
          onClick={() => setActiveTab('ai')}
          className={`py-2 rounded-xl text-xs font-bold flex flex-col items-center gap-1 transition-all relative cursor-pointer ${
            activeTab === 'ai'
              ? 'bg-gradient-to-r from-purple-500 to-fuchsia-600 text-white shadow-lg shadow-purple-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
          }`}
          title="AI Assistant"
        >
          <Bot className="w-4 h-4 text-cyan-300" />
          <span className="text-[10px]">AI</span>
          <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`py-2 rounded-xl text-xs font-bold flex flex-col items-center gap-1 transition-all cursor-pointer ${
            activeTab === 'settings'
              ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/20'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
          }`}
          title="Settings"
        >
          <Settings className="w-4 h-4" />
          <span className="text-[10px]">সেটিংস</span>
        </button>
      </div>

      {/* Conversations / Direct Chat List */}
      <div className="flex-1 overflow-y-auto px-3 py-2 space-y-1">
        <div className="flex items-center justify-between px-2 py-1 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
          <span>সক্রিয় চ্যাট তালিকা ({recentUsers.length})</span>
          <Sparkles className="w-3 h-3 text-cyan-400" />
        </div>

        {recentUsers.length === 0 ? (
          <div className="text-center py-10 px-4 text-slate-400">
            <div className="w-12 h-12 mx-auto mb-3 rounded-2xl bg-[#0f1638] border border-slate-800 flex items-center justify-center text-slate-500">
              <MessageSquare className="w-6 h-6 text-slate-500" />
            </div>
            <p className="text-xs font-bold text-slate-300">কোনো চ্যাট এখনো শুরু হয়নি</p>
            <p className="text-[11px] text-slate-500 mt-1 leading-relaxed">
              উপরের বক্সে কোনো ১১-সংখ্যার Virtual ID লিখুন অথবা কন্ট্যাক্ট যুক্ত করুন।
            </p>
          </div>
        ) : (
          recentUsers.map((user) => {
            const isSelected = selectedChatUser?.uid === user.uid && activeTab === 'chats';
            return (
              <button
                key={user.uid}
                onClick={() => {
                  setActiveTab('chats');
                  onSelectChatUser(user);
                }}
                className={`w-full p-3 rounded-2xl text-left flex items-center gap-3 transition-all cursor-pointer ${
                  isSelected
                    ? 'bg-gradient-to-r from-[#172044] to-[#121835] border border-cyan-500/40 shadow-md'
                    : 'hover:bg-[#101735]/70 border border-transparent'
                }`}
              >
                <div className="relative shrink-0">
                  {user.photoURL ? (
                    <img src={user.photoURL} alt={user.name} className="w-11 h-11 rounded-xl object-cover" />
                  ) : (
                    <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${user.avatarBg || 'from-indigo-500 to-purple-600'} flex items-center justify-center text-sm font-bold text-white`}>
                      {getInitials(user.name)}
                    </div>
                  )}
                  {user.online ? (
                    <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-emerald-500 rounded-full ring-2 ring-[#080d22]" />
                  ) : (
                    <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-slate-600 rounded-full ring-2 ring-[#080d22]" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-0.5">
                    <span className="text-xs font-bold text-white truncate">{user.name}</span>
                    <span className="text-[10px] text-slate-400 shrink-0 font-mono">
                      {user.lastSeen ? formatTimestamp(user.lastSeen) : 'Active'}
                    </span>
                  </div>

                  <p className="text-[11px] text-slate-400 truncate">
                    {user.statusText || user.bio || `Virtual ID: ${formatVirtualId(user.virtualId)}`}
                  </p>
                </div>
              </button>
            );
          })
        )}
      </div>

      {/* Logout Footer */}
      <div className="p-3 border-t border-slate-800/80 bg-[#060a1d]">
        <button
          onClick={onLogout}
          className="w-full py-2.5 px-3 rounded-xl bg-rose-950/30 hover:bg-rose-900/50 text-rose-300 border border-rose-800/40 text-xs font-bold flex items-center justify-center gap-2 transition-colors cursor-pointer"
        >
          <LogOut className="w-4 h-4" />
          <span>লগআউট করুন</span>
        </button>
      </div>
    </aside>
  );
};
