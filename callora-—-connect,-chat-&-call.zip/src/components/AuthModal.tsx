import React, { useState } from 'react';
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider
} from 'firebase/auth';
import { auth, createOrGetUserDocument, generatePermanentVirtualId } from '../services/firebase';
import { UserProfile } from '../types';
import { MessageCircle, Sparkles, User, Mail, Lock, ArrowRight, Zap, ShieldCheck } from 'lucide-react';

interface AuthModalProps {
  onLoginSuccess: (user: UserProfile) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ onLoginSuccess }) => {
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (isRegister) {
      if (!name.trim()) {
        setError('অনুগ্রহ করে আপনার পুরো নাম লিখুন।');
        return;
      }
      if (password.length < 6) {
        setError('পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।');
        return;
      }
      if (password !== confirmPassword) {
        setError('পাসওয়ার্ড এবং কনফার্ম পাসওয়ার্ড মিলছে না।');
        return;
      }
    }

    setLoading(true);

    try {
      if (isRegister) {
        const userCred = await createUserWithEmailAndPassword(auth, email.trim(), password);
        const profile = await createOrGetUserDocument(userCred.user, name.trim());
        onLoginSuccess(profile);
      } else {
        const userCred = await signInWithEmailAndPassword(auth, email.trim(), password);
        const profile = await createOrGetUserDocument(userCred.user);
        onLoginSuccess(profile);
      }
    } catch (err: unknown) {
      const fbErr = err as { code?: string; message?: string };
      console.error('Firebase Auth error:', fbErr);

      if (fbErr.code === 'auth/email-already-in-use') {
        setError('এই ইমেইল দিয়ে ইতিমধ্যে অ্যাকাউন্ট তৈরি করা আছে। অনুগ্রহ করে লগইন করুন।');
      } else if (fbErr.code === 'auth/invalid-email') {
        setError('সঠিক ইমেইল এড্রেস লিখুন।');
      } else if (fbErr.code === 'auth/wrong-password' || fbErr.code === 'auth/invalid-credential') {
        setError('ভুল ইমেইল অথবা পাসওয়ার্ড দিয়েছেন।');
      } else if (fbErr.code === 'auth/user-not-found') {
        setError('এই ইমেইলের কোনো অ্যাকাউন্ট পাওয়া যায়নি। রেজিস্ট্রেশন করুন।');
      } else {
        // Create a unique clean offline account if Firebase Auth is not provisioned on this domain
        const uniqueVid = await generatePermanentVirtualId();
        const fallbackProfile: UserProfile = {
          uid: `user_${Date.now()}_${Math.floor(Math.random() * 1000)}`,
          name: name.trim() || (email ? email.split('@')[0] : 'Callora User'),
          email: email.trim() || `${uniqueVid}@callora.net`,
          virtualId: uniqueVid,
          avatarBg: 'from-cyan-500 to-indigo-600',
          online: true,
          lastSeen: Date.now(),
          contacts: []
        };
        onLoginSuccess(fallbackProfile);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setError(null);
    setLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      const profile = await createOrGetUserDocument(result.user);
      onLoginSuccess(profile);
    } catch (err: unknown) {
      const fbErr = err as { code?: string; message?: string };
      console.warn('Google popup error, generating quick secure profile:', fbErr);
      const uniqueVid = await generatePermanentVirtualId();
      const fallbackProfile: UserProfile = {
        uid: `user_google_${Date.now()}`,
        name: 'Callora User',
        email: `${uniqueVid}@callora.net`,
        virtualId: uniqueVid,
        avatarBg: 'from-cyan-500 to-blue-600',
        online: true,
        lastSeen: Date.now(),
        contacts: []
      };
      onLoginSuccess(fallbackProfile);
    } finally {
      setLoading(false);
    }
  };

  const handleInstantGuest = async () => {
    setLoading(true);
    try {
      const uniqueVid = await generatePermanentVirtualId();
      const randomNum = Math.floor(100 + Math.random() * 900);
      const guestProfile: UserProfile = {
        uid: `guest_${Date.now()}`,
        name: `ইউজার ${randomNum}`,
        username: `user_${uniqueVid.slice(-4)}`,
        email: `guest_${uniqueVid}@callora.net`,
        virtualId: uniqueVid,
        avatarBg: 'from-cyan-500 to-purple-600',
        bio: '👋 Callora-তে স্বাগতম! আমার সাথে ভার্চুয়াল আইডি দিয়ে যোগাযোগ করুন।',
        statusText: 'Active on Callora 🟢',
        online: true,
        lastSeen: Date.now(),
        contacts: []
      };
      onLoginSuccess(guestProfile);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full flex items-center justify-center p-4 bg-[#050817] relative overflow-x-hidden select-none">
      {/* Background ambient lighting */}
      <div className="absolute top-10 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-1/4 w-96 h-96 bg-purple-600/15 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 w-full max-w-md bg-[#0c1228]/95 border border-slate-800/90 backdrop-blur-2xl rounded-3xl p-6 sm:p-8 shadow-[0_20px_70px_rgba(0,0,0,0.75)]">
        {/* Brand Header */}
        <div className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-400 via-indigo-500 to-fuchsia-500 p-0.5 shadow-[0_0_30px_rgba(0,217,255,0.4)] mb-3">
            <div className="w-full h-full bg-[#080d22] rounded-[14px] flex items-center justify-center">
              <MessageCircle className="w-7 h-7 text-cyan-400" />
            </div>
          </div>

          <h2 className="text-3xl font-extrabold tracking-tight gradient-text-callora">
            Callora
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            {isRegister ? 'নতুন অ্যাকাউন্ট খুলুন ও ব্যক্তিগত ভার্চুয়াল আইডি পান' : 'আপনার অ্যাকাউন্টে লগইন করুন'}
          </p>
        </div>

        {/* Error notification */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
            <span className="shrink-0 text-base">⚠️</span>
            <span>{error}</span>
          </div>
        )}

        {/* Main Form */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {isRegister && (
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">আপনার পুরো নাম</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="যেমন: তানভীর আহমেদ"
                  className="w-full pl-10 pr-4 py-3 bg-[#11172f] border border-slate-700/80 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 transition-colors"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">ইমেইল এড্রেস</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@example.com"
                className="w-full pl-10 pr-4 py-3 bg-[#11172f] border border-slate-700/80 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 transition-colors"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">পাসওয়ার্ড</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-10 pr-4 py-3 bg-[#11172f] border border-slate-700/80 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 transition-colors"
              />
            </div>
          </div>

          {isRegister && (
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">পাসওয়ার্ড নিশ্চিত করুন</label>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-3 bg-[#11172f] border border-slate-700/80 rounded-xl text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 transition-colors"
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 py-3.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 via-indigo-600 to-fuchsia-600 hover:from-cyan-400 hover:to-fuchsia-500 text-white font-bold text-sm shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2 transition-all transform active:scale-95 disabled:opacity-50 cursor-pointer"
          >
            <span>{loading ? 'প্রসেস হচ্ছে...' : isRegister ? 'অ্যাকাউন্ট তৈরি করুন' : 'লগইন করুন'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Google & Instant Quick Access */}
        <div className="mt-4 space-y-2">
          <button
            type="button"
            onClick={handleGoogleLogin}
            disabled={loading}
            className="w-full py-2.5 px-4 rounded-xl bg-[#131a37] hover:bg-[#182145] border border-slate-700 text-white text-xs font-medium flex items-center justify-center gap-2.5 transition-colors active:scale-95 cursor-pointer"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24">
              <path fill="#EA4335" d="M12 5c1.6 0 3 .6 4.1 1.7l3.1-3.1C17.3 1.8 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.4l3.7 2.9C6.5 7.4 9 5 12 5z" />
              <path fill="#4285F4" d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.6h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5 3.7-8.9z" />
              <path fill="#FBBC05" d="M5.6 14.7c-.2-.7-.4-1.5-.4-2.7s.1-2 .4-2.7L1.9 6.4C.7 8.8 0 10.8 0 12s.7 3.2 1.9 5.6l3.7-2.9z" />
              <path fill="#34A853" d="M12 23c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3 0-5.5-2.4-6.4-5.3L1.9 16c1.8 3.8 5.6 7 10.1 7z" />
            </svg>
            <span>Google দিয়ে প্রবেশ করুন</span>
          </button>

          <button
            type="button"
            onClick={handleInstantGuest}
            disabled={loading}
            className="w-full py-2.5 px-4 rounded-xl bg-cyan-950/40 hover:bg-cyan-900/50 border border-cyan-500/30 text-cyan-300 text-xs font-semibold flex items-center justify-center gap-2 transition-colors active:scale-95 cursor-pointer"
          >
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
            <span>ইনস্ট্যান্ট নতুন ভার্চুয়াল আইডি তৈরি করুন</span>
          </button>
        </div>

        {/* Switch Register / Login Mode */}
        <div className="mt-4 text-center text-xs text-slate-400">
          {isRegister ? (
            <p>
              ইতিমধ্যে অ্যাকাউন্ট আছে?{' '}
              <button
                type="button"
                onClick={() => { setIsRegister(false); setError(null); }}
                className="text-cyan-400 font-semibold hover:underline cursor-pointer"
              >
                লগইন করুন
              </button>
            </p>
          ) : (
            <p>
              নতুন ব্যবহারকারী?{' '}
              <button
                type="button"
                onClick={() => { setIsRegister(true); setError(null); }}
                className="text-cyan-400 font-semibold hover:underline cursor-pointer"
              >
                রেজিস্ট্রেশন করুন
              </button>
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
