import React, { useState } from 'react';
import {
  User,
  Shield,
  Volume2,
  VolumeX,
  Languages,
  QrCode,
  Copy,
  Check,
  Save,
  Sparkles,
  Lock,
  Smartphone,
  LogOut
} from 'lucide-react';
import { UserProfile } from '../types';
import { formatVirtualId, getInitials } from '../services/firebase';
import { sound } from '../services/sound';

interface SettingsViewProps {
  currentUser: UserProfile;
  onUpdateProfile: (updated: Partial<UserProfile>) => void;
  onOpenIdCard: () => void;
  onLogout: () => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  currentUser,
  onUpdateProfile,
  onOpenIdCard,
  onLogout
}) => {
  const [name, setName] = useState(currentUser.name);
  const [statusText, setStatusText] = useState(currentUser.statusText || 'Available on Callora 🟢');
  const [bio, setBio] = useState(currentUser.bio || '');
  const [isSoundMuted, setIsSoundMuted] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [copiedId, setCopiedId] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      name: name.trim() || currentUser.name,
      statusText: statusText.trim(),
      bio: bio.trim()
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const toggleSound = () => {
    const next = !isSoundMuted;
    setIsSoundMuted(next);
    sound.setMuted(next);
  };

  const handleCopyId = () => {
    navigator.clipboard.writeText(currentUser.virtualId);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#050817] p-4 lg:p-8 overflow-y-auto select-none">
      <div className="max-w-3xl mx-auto w-full space-y-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#0c1433] via-[#0e173b] to-[#161a45] p-6 rounded-3xl border border-cyan-500/20 shadow-xl flex items-center justify-between">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/70 border border-cyan-400/30 text-cyan-300 text-xs font-semibold uppercase tracking-wider mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>User Profile & Security</span>
            </div>
            <h2 className="text-2xl font-black text-white">সেটিংস ও প্রোফাইল</h2>
            <p className="text-xs text-slate-400 mt-1">আপনার অ্যাকাউন্ট ও অডিও-ভিডিও অপশন কাস্টমাইজ করুন</p>
          </div>

          <button
            onClick={onOpenIdCard}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-cyan-500/25 transition-all"
          >
            <QrCode className="w-4 h-4" />
            <span className="hidden sm:inline">আমার ID কার্ড</span>
          </button>
        </div>

        {/* Profile Card & Edit Form */}
        <form onSubmit={handleSave} className="bg-[#0c1228] p-6 rounded-2xl border border-slate-800 space-y-4 shadow-md">
          <div className="flex items-center gap-4 pb-4 border-b border-slate-800">
            {currentUser.photoURL ? (
              <img src={currentUser.photoURL} alt={currentUser.name} className="w-16 h-16 rounded-2xl object-cover ring-2 ring-cyan-400" />
            ) : (
              <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${currentUser.avatarBg || 'from-cyan-500 to-indigo-600'} flex items-center justify-center text-2xl font-black text-white ring-2 ring-cyan-400`}>
                {getInitials(name)}
              </div>
            )}

            <div className="flex-1 min-w-0">
              <h3 className="text-base font-bold text-white truncate">{name}</h3>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-xs text-cyan-300 font-mono bg-cyan-950/80 px-2.5 py-0.5 rounded-md border border-cyan-500/30">
                  {formatVirtualId(currentUser.virtualId)}
                </span>
                <button
                  type="button"
                  onClick={handleCopyId}
                  className="p-1 hover:text-cyan-300 text-slate-400"
                  title="Copy Virtual ID"
                >
                  {copiedId ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">ডিসপ্লে নাম</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-4 py-2.5 bg-[#111735] border border-slate-700 rounded-xl text-white placeholder-slate-500 text-xs focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">স্ট্যাটাস / মুড</label>
            <input
              type="text"
              value={statusText}
              onChange={(e) => setStatusText(e.target.value)}
              placeholder="যেমন: Coding on Callora 🚀"
              className="w-full px-4 py-2.5 bg-[#111735] border border-slate-700 rounded-xl text-white placeholder-slate-500 text-xs focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">বায়ো (Bio)</label>
            <textarea
              rows={2}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="আপনার সম্পর্কে কিছু লিখুন..."
              className="w-full px-4 py-2 bg-[#111735] border border-slate-700 rounded-xl text-white placeholder-slate-500 text-xs focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            {savedSuccess ? (
              <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                <Check className="w-4 h-4" />
                <span>পরিবর্তন সংরক্ষণ করা হয়েছে!</span>
              </span>
            ) : <span />}

            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-cyan-500/25 transition-all"
            >
              <Save className="w-4 h-4" />
              <span>সংরক্ষণ করুন</span>
            </button>
          </div>
        </form>

        {/* Audio & App Preferences */}
        <div className="bg-[#0c1228] p-6 rounded-2xl border border-slate-800 space-y-4 shadow-md">
          <h3 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-cyan-400" />
            <span>অ্যাপ সাউন্ড ও অডিও সেটিংস</span>
          </h3>

          <div className="flex items-center justify-between p-3 rounded-xl bg-[#111735] border border-slate-800">
            <div>
              <p className="text-xs font-bold text-white">কল রিংটোন ও মেসেজ চিম সাউন্ড</p>
              <p className="text-[11px] text-slate-400">ইনকামিং কল এবং মেসেজ এলে সিন্থেসাইজড সাউন্ড বাজানো হবে</p>
            </div>

            <button
              onClick={toggleSound}
              className={`p-2.5 rounded-xl border flex items-center gap-2 text-xs font-bold transition-all ${
                isSoundMuted
                  ? 'bg-rose-950/50 border-rose-600/40 text-rose-300'
                  : 'bg-emerald-950/50 border-emerald-600/40 text-emerald-300'
              }`}
            >
              {isSoundMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
              <span>{isSoundMuted ? 'নিঃশব্দ (Muted)' : 'চালু (Sound On)'}</span>
            </button>
          </div>

          <div className="flex items-center justify-between p-3 rounded-xl bg-[#111735] border border-slate-800">
            <div>
              <p className="text-xs font-bold text-white">এনক্রিপশন ও নিরাপত্তা</p>
              <p className="text-[11px] text-slate-400">WebRTC DTLS/SRTP এবং পিয়ার-টু-পিয়ার স্ট্রিমিং সুরক্ষিত</p>
            </div>
            <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
              <Shield className="w-4 h-4" />
              <span>Active</span>
            </span>
          </div>
        </div>

        {/* Logout action */}
        <div className="pt-2">
          <button
            onClick={onLogout}
            className="w-full py-3 px-4 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/40 font-bold text-xs flex items-center justify-center gap-2 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>লগআউট করুন</span>
          </button>
        </div>
      </div>
    </div>
  );
};
