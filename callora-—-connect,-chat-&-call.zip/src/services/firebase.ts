import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut as fbSignOut, 
  onAuthStateChanged,
  User as FbUser 
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  collection, 
  query, 
  where, 
  orderBy, 
  limit, 
  onSnapshot, 
  serverTimestamp, 
  updateDoc,
  arrayUnion,
  arrayRemove
} from 'firebase/firestore';
import { UserProfile, ChatMessage, ChatThread, CallSession } from '../types';

// Updated with Callora9 Firebase Project Configuration
export const firebaseConfig = {
  apiKey: "AIzaSyBd85pzo16nS5aWs7lqaMgS9Z2ai0P2t2E",
  authDomain: "callora9.firebaseapp.com",
  projectId: "callora9",
  storageBucket: "callora9.firebasestorage.app",
  messagingSenderId: "499528760380",
  appId: "1:499528760380:web:6b06f20a039f0234121739",
  measurementId: "G-7QV40087HJ"
};

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
export const auth = getAuth(app);
export const db = getFirestore(app);

// Generate unique 11-digit permanent Virtual ID (format: 210 + 8 random digits)
export function generateLocalVirtualId(): string {
  const rand = Math.floor(10000000 + Math.random() * 90000000);
  return `210${rand}`;
}

export async function generatePermanentVirtualId(): Promise<string> {
  try {
    for (let i = 0; i < 10; i++) {
      const vid = generateLocalVirtualId();
      const idRef = doc(db, 'virtual_ids', vid);
      const snap = await getDoc(idRef);
      if (!snap.exists()) {
        return vid;
      }
    }
  } catch (e) {
    console.warn('Firebase virtual ID verification skipped, using generated local ID:', e);
  }
  return generateLocalVirtualId();
}

// User Document Creation & Persistence
export async function createOrGetUserDocument(
  fbUser: FbUser | { uid: string; email?: string | null; displayName?: string | null; photoURL?: string | null }, 
  customName?: string, 
  customUsername?: string
): Promise<UserProfile> {
  const userRef = doc(db, 'users', fbUser.uid);
  try {
    const snap = await getDoc(userRef);
    if (snap.exists()) {
      const data = snap.data() as UserProfile;
      // update online status
      try {
        await updateDoc(userRef, {
          online: true,
          lastSeen: Date.now()
        });
      } catch {}
      return { ...data, online: true };
    }
  } catch (e) {
    console.warn('Firestore read error in createOrGetUserDocument:', e);
  }

  // Create new unique user profile
  const virtualId = await generatePermanentVirtualId();
  const emailVal = fbUser.email || `${virtualId}@callora.net`;
  const nameVal = customName || fbUser.displayName || (emailVal.includes('@') ? emailVal.split('@')[0] : 'Callora User');
  
  const newUser: UserProfile = {
    uid: fbUser.uid,
    name: nameVal,
    username: customUsername || (fbUser.email ? fbUser.email.split('@')[0] : `user_${virtualId.slice(-4)}`),
    email: emailVal,
    virtualId: virtualId,
    photoURL: fbUser.photoURL || '',
    avatarBg: getRandomAvatarGradient(),
    bio: '👋 Hey there! I am using Callora to connect, chat and call securely.',
    statusText: 'Available on Callora 🟢',
    online: true,
    lastSeen: Date.now(),
    createdAt: Date.now(),
    contacts: []
  };

  try {
    await setDoc(userRef, newUser);
    // Index virtual ID to direct UID lookup
    await setDoc(doc(db, 'virtual_ids', virtualId), {
      uid: fbUser.uid,
      name: newUser.name,
      virtualId: virtualId,
      createdAt: serverTimestamp()
    });
  } catch (e) {
    console.warn('Firestore write error, saving to local state:', e);
  }

  return newUser;
}

// Search User by 11-digit Virtual ID or UID
export async function findUserByVirtualId(virtualId: string): Promise<UserProfile | null> {
  const cleanId = virtualId.replace(/\s+/g, '').trim();
  if (!cleanId) return null;

  try {
    // 1. Direct index lookup in virtual_ids collection
    const idRef = doc(db, 'virtual_ids', cleanId);
    const idSnap = await getDoc(idRef);
    if (idSnap.exists()) {
      const { uid } = idSnap.data() as { uid: string };
      if (uid) {
        const userRef = doc(db, 'users', uid);
        const userSnap = await getDoc(userRef);
        if (userSnap.exists()) {
          return userSnap.data() as UserProfile;
        }
      }
    }

    // 2. Query users collection by virtualId
    const q = query(collection(db, 'users'), where('virtualId', '==', cleanId), limit(1));
    const querySnapshot = await getDocs(q);
    if (!querySnapshot.empty) {
      return querySnapshot.docs[0].data() as UserProfile;
    }

    // 3. Query users collection by username or email
    const qUser = query(collection(db, 'users'), where('username', '==', cleanId.toLowerCase()), limit(1));
    const qUserSnap = await getDocs(qUser);
    if (!qUserSnap.empty) {
      return qUserSnap.docs[0].data() as UserProfile;
    }
  } catch (e) {
    console.warn('Firestore search error:', e);
  }
  return null;
}

// Add user to personal contacts
export async function addContactToFirestore(currentUid: string, contactUid: string): Promise<void> {
  try {
    const userRef = doc(db, 'users', currentUid);
    await updateDoc(userRef, {
      contacts: arrayUnion(contactUid)
    });
  } catch (e) {
    console.warn('Could not sync contact to Firestore:', e);
  }
}

// Remove contact from personal contacts
export async function removeContactFromFirestore(currentUid: string, contactUid: string): Promise<void> {
  try {
    const userRef = doc(db, 'users', currentUid);
    await updateDoc(userRef, {
      contacts: arrayRemove(contactUid)
    });
  } catch (e) {
    console.warn('Could not remove contact from Firestore:', e);
  }
}

// Load contacts by UIDs
export async function loadContactsByUids(uids: string[]): Promise<UserProfile[]> {
  if (!uids || uids.length === 0) return [];
  const profiles: UserProfile[] = [];
  
  for (const uid of uids) {
    try {
      const uRef = doc(db, 'users', uid);
      const snap = await getDoc(uRef);
      if (snap.exists()) {
        profiles.push(snap.data() as UserProfile);
      }
    } catch (err) {
      console.warn(`Error loading contact profile for ${uid}:`, err);
    }
  }
  return profiles;
}

export function getChatId(uid1: string, uid2: string): string {
  return [uid1, uid2].sort().join('__');
}

// Helpers for friendly initials & color gradients
export function getInitials(name?: string): string {
  if (!name) return 'C';
  const parts = name.trim().split(' ');
  if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
  return (parts[0][0] + parts[1][0]).toUpperCase();
}

export function formatVirtualId(id?: string): string {
  if (!id) return '';
  const clean = id.replace(/\s+/g, '');
  if (clean.length !== 11) return id;
  return `${clean.slice(0, 3)} ${clean.slice(3, 7)} ${clean.slice(7)}`;
}

export function formatTimestamp(timestamp?: number | string): string {
  if (!timestamp) return '';
  const date = typeof timestamp === 'number' ? new Date(timestamp) : new Date(timestamp);
  if (isNaN(date.getTime())) return '';
  
  const now = new Date();
  const isToday = date.toDateString() === now.toDateString();
  if (isToday) {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
  return date.toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function getRandomAvatarGradient(): string {
  const gradients = [
    'from-cyan-500 to-blue-600',
    'from-fuchsia-500 to-rose-600',
    'from-indigo-500 to-purple-600',
    'from-emerald-500 to-teal-600',
    'from-amber-500 to-orange-600',
    'from-violet-500 to-indigo-700'
  ];
  return gradients[Math.floor(Math.random() * gradients.length)];
}
