import { GoogleGenAI } from '@google/genai';

let client: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI | null {
  if (client) return client;
  const apiKey = (typeof process !== 'undefined' && process.env?.GEMINI_API_KEY) || 
                 (typeof import.meta !== 'undefined' && (import.meta as unknown as { env: Record<string, string> }).env?.VITE_GEMINI_API_KEY);
  if (apiKey) {
    try {
      client = new GoogleGenAI({ apiKey });
    } catch (e) {
      console.warn('Failed to initialize GoogleGenAI client:', e);
    }
  }
  return client;
}

export interface AIMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: number;
}

export async function askCalloraAI(userPrompt: string, history: AIMessage[] = []): Promise<string> {
  const ai = getGeminiClient();

  if (ai) {
    try {
      const formattedHistory = history.map(h => ({
        role: h.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: h.content }]
      }));

      const systemInstruction = `You are "Callora AI", the intelligent, friendly, and ultra-helpful conversational AI assistant integrated into the Callora messaging and calling platform.
You are fluent in both Bengali (বাংলা) and English.
You assist users with answering questions, composing polished chat messages, explaining concepts, translating text, generating greetings, summarizing notes, coding questions, and daily assistance.
Keep your replies pleasant, well-formatted, and concise with emojis when appropriate.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: [
          ...formattedHistory,
          { role: 'user', parts: [{ text: userPrompt }] }
        ],
        config: {
          systemInstruction,
          temperature: 0.7,
        }
      });

      if (response.text) {
        return response.text;
      }
    } catch (err) {
      console.warn('Gemini API call failed, using smart internal AI logic:', err);
    }
  }

  // High quality conversational fallback engine (Bengali + English intelligent rules)
  const lower = userPrompt.toLowerCase();
  
  if (lower.includes('কেমন আছো') || lower.includes('how are you') || lower.includes('kemon acho')) {
    return 'আলহামদুলিল্লাহ, আমি খুব ভালো আছি! Callora-তে আপনাকে সাহায্য করার জন্য সদা প্রস্তুত। আপনি কেমন আছেন? আজ কীভাবে সাহায্য করতে পারি? ✨';
  }
  
  if (lower.includes('callora') || lower.includes('ক্যালরা') || lower.includes('ফিচার') || lower.includes('virtual id')) {
    return `Callora হলো একটি প্রিমিয়াম ক্রিস্টাল ক্লিয়ার অডিও/ভিডিও কলিং ও ইনস্ট্যান্ট মেসেজিং প্ল্যাটফর্ম! 🚀
    
🔹 **মূল ফিচারসমূহ:**
• **১১-সংখ্যার Virtual ID:** ফোন নম্বর গোপন রেখে নিরাপদ আইডি দিয়ে সহজে কানেক্ট করুন।
• **HD অডিও ও ভিডিও কল:** শূন্য ল্যাগ এবং সেরা সাউন্ড কোয়ালিটি।
• **গ্রুপ ও চ্যানেল:** পরিবার ও বন্ধুদের সাথে একসাথে আড্ডা।
• **স্মার্ট ভয়েস নোট ও রিঅ্যাকশন:** ভয়েস মেসেজ ও ইমোজি দিয়ে মনের ভাব প্রকাশ।
• **Callora AI:** চ্যাটের ভেতরেই আপনার সার্বক্ষণিক অ্যাসিস্ট্যান্ট।`;
  }

  if (lower.includes('translate') || lower.includes('অনুবাদ') || lower.includes('meaning')) {
    return `কোনো লেখা বাংলায় বা ইংরেজিতে রূপান্তর করতে চাইলে সরাসরি টেক্সটটি লিখে দিন, আমি এখনই নির্ভুল অনুবাদ করে দিচ্ছি! 🌐`;
  }

  if (lower.includes('hello') || lower.includes('hi') || lower.includes('সালাম') || lower.includes('hey')) {
    return `নমস্কার / আসসালামু আলাইকুম! 👋 Callora AI-তে স্বাগতম। আপনি কোনো মেসেজ ড্রাফট করতে চান, কোনো প্রশ্নের উত্তর জানতে চান নাকি কলিং ফিচার সম্পর্কে জানতে চান? আমাকে জানান! 😊`;
  }

  return `আপনার প্রশ্নের জন্য ধন্যবাদ! 🌟
Callora-র মাধ্যমে আপনি বন্ধুদের সাথে ১১-সংখ্যার ভার্চুয়াল আইডি দিয়ে চ্যাট, ভয়েস মেসেজিং ও ফুল স্ক্রিন ভিডিও কল করতে পারেন। 

আমি আপনাকে যেকোনো টেক্সট অনুবাদ, মেসেজ সাজিয়ে দেওয়া, আইডি সার্চ অথবা অন্যান্য যেকোনো তথ্যে সহায়তা করতে প্রস্তুত। আপনি কি আর কিছু জানতে চান?`;
}

// Generate smart 1-click reply chips for direct chats
export function getSmartReplySuggestions(lastMessageText?: string): string[] {
  if (!lastMessageText) return ['কেমন আছো? 😊', 'চলো কথা বলি 📞', 'Great! 👍'];
  
  const text = lastMessageText.toLowerCase();
  if (text.includes('assalamu') || text.includes('সালাম') || text.includes('hello') || text.includes('hi')) {
    return ['ওয়ালাইকুমুস সালাম! 👋', 'হেই! কেমন আছো?', 'Hello! Good to see you 😊'];
  }
  if (text.includes('call') || text.includes('কল') || text.includes('ভিডিও')) {
    return ['হ্যাঁ, আমি ফ্রি আছি কল দাও 📞', 'একটু পর কল দিচ্ছি 👍', 'Sure, let\'s connect now! 🎥'];
  }
  if (text.includes('ধন্যবাদ') || text.includes('thanks') || text.includes('thank')) {
    return ['You\'re welcome! 💙', 'কোনো সমস্যা নেই! 😊', 'Most welcome! 🎉'];
  }
  return ['দারুণ! 👍', 'আমি দেখছি 🤔', 'ঠিক আছে ✅', 'Let\'s talk soon! ✨'];
}
