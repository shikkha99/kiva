import React, { useState, useEffect, useRef } from 'react';
import { onAuthStateChanged, signOut as fbSignOut } from 'firebase/auth';
import {
  collection,
  doc,
  setDoc,
  getDoc,
  onSnapshot,
  query,
  orderBy,
  where,
  serverTimestamp,
  addDoc
} from 'firebase/firestore';
import {
  auth,
  db,
  createOrGetUserDocument,
  getChatId,
  findUserByVirtualId,
  formatVirtualId,
  addContactToFirestore,
  removeContactFromFirestore,
  loadContactsByUids
} from './services/firebase';
import { UserProfile, ChatMessage, ActiveTab, CallSession, MessageType, GroupDetails } from './types';
import { sound } from './services/sound';
import { Splash } from './components/Splash';
import { AuthModal } from './components/AuthModal';
import { Sidebar } from './components/Sidebar';
import { ChatView } from './components/ChatView';
import { ContactsView } from './components/ContactsView';
import { GroupsView } from './components/GroupsView';
import { AIView } from './components/AIView';
import { SettingsView } from './components/SettingsView';
import { CallModal } from './components/CallModal';
import { VirtualIdCardModal } from './components/VirtualIdCardModal';
import { MessageSquare, Sparkles, QrCode, Share2, Copy, Check, UserPlus, PhoneCall, ShieldCheck, Bot, Users, MessagesSquare, Settings } from 'lucide-react';

export default function App() {
  const [showSplash, setShowSplash] = useState(true);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [activeTab, setActiveTab] = useState<ActiveTab>('chats');
  const [selectedChatUser, setSelectedChatUser] = useState<UserProfile | null>(null);
  const [contacts, setContacts] = useState<UserProfile[]>([]);
  const [recentChatUsers, setRecentChatUsers] = useState<UserProfile[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  
  // Search state
  const [searchResult, setSearchResult] = useState<UserProfile | null>(null);
  const [searchError, setSearchError] = useState<string | null>(null);

  // Calling state
  const [activeCall, setActiveCall] = useState<CallSession | null>(null);
  const [incomingCall, setIncomingCall] = useState<CallSession | null>(null);

  // ID Card modal
  const [showIdCardModal, setShowIdCardModal] = useState(false);
  const [copiedMyId, setCopiedMyId] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  // Active Group Chat
  const [activeGroup, setActiveGroup] = useState<GroupDetails | null>(null);

  // Toast notifications
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const unsubMessagesRef = useRef<(() => void) | null>(null);
  const unsubCallsRef = useRef<(() => void) | null>(null);
  const unsubUserChatsRef = useRef<(() => void) | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // 1. Splash Screen Timer & Auth State Listener
  useEffect(() => {
    const splashTimer = setTimeout(() => {
      setShowSplash(false);
    }, 1500);

    const unsubscribeAuth = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        try {
          const profile = await createOrGetUserDocument(fbUser);
          setCurrentUser(profile);
        } catch (e) {
          console.warn('Could not load user profile from auth:', e);
        }
      }
    });

    return () => {
      clearTimeout(splashTimer);
      unsubscribeAuth();
    };
  }, []);

  // 2. Load contacts & listen to User's Firestore doc and Chats
  useEffect(() => {
    if (!currentUser) return;

    // A. Check URL parameters / hash for direct connect (e.g. #id=210XXXXXXXX or ?id=210XXXXXXXX)
    const checkDirectUrlConnect = async () => {
      try {
        const hash = window.location.hash;
        const search = window.location.search;
        let targetId = '';

        if (hash.includes('id=')) {
          targetId = hash.split('id=')[1]?.split('&')[0];
        } else if (search.includes('id=')) {
          targetId = new URLSearchParams(search).get('id') || '';
        } else if (hash.startsWith('#210')) {
          targetId = hash.replace('#', '');
        }

        if (targetId && targetId !== currentUser.virtualId) {
          const found = await findUserByVirtualId(targetId);
          if (found) {
            setSelectedChatUser(found);
            setActiveTab('chats');
            showToast(`💬 ${found.name}-এর সাথে চ্যাট শুরু হয়েছে।`);
          }
        }
      } catch (err) {
        console.warn('Direct URL detection error:', err);
      }
    };
    checkDirectUrlConnect();

    // B. Realtime sync of user profile and contact list
    const userDocRef = doc(db, 'users', currentUser.uid);
    const unsubUser = onSnapshot(userDocRef, async (snap) => {
      if (snap.exists()) {
        const data = snap.data() as UserProfile;
        if (data.contacts && Array.isArray(data.contacts)) {
          const loaded = await loadContactsByUids(data.contacts);
          setContacts(loaded);
        }
      }
    });

    // C. Realtime sync of all active chats involving currentUser
    try {
      const chatsQuery = query(
        collection(db, 'chats'),
        where('participants', 'array-contains', currentUser.uid)
      );

      const unsubChats = onSnapshot(chatsQuery, async (snapshot) => {
        const partnerUids = new Set<string>();
        snapshot.forEach((d) => {
          const chatData = d.data();
          if (Array.isArray(chatData.participants)) {
            chatData.participants.forEach((uid: string) => {
              if (uid !== currentUser.uid) {
                partnerUids.add(uid);
              }
            });
          }
        });

        if (partnerUids.size > 0) {
          const loadedChatPartners = await loadContactsByUids(Array.from(partnerUids));
          setRecentChatUsers(loadedChatPartners);
        } else {
          setRecentChatUsers([]);
        }
      });

      unsubUserChatsRef.current = unsubChats;
    } catch (e) {
      console.warn('Error querying active chats:', e);
    }

    return () => {
      unsubUser();
      if (unsubUserChatsRef.current) {
        unsubUserChatsRef.current();
      }
    };
  }, [currentUser]);

  // 3. Listen for Incoming Calls in Firestore
  useEffect(() => {
    if (!currentUser) return;

    try {
      const q = query(
        collection(db, 'calls'),
        where('receiverId', '==', currentUser.uid),
        where('status', 'in', ['calling', 'ringing'])
      );

      const unsub = onSnapshot(q, (snapshot) => {
        snapshot.docChanges().forEach((change) => {
          if (change.type === 'added') {
            const callData = change.doc.data() as CallSession;
            setIncomingCall(callData);
          } else if (change.type === 'removed' || change.type === 'modified') {
            const callData = change.doc.data() as CallSession;
            if (callData.status === 'ended' || callData.status === 'declined') {
              setIncomingCall(null);
            }
          }
        });
      });

      unsubCallsRef.current = unsub;
      return () => unsub();
    } catch (e) {
      console.warn('Firestore call subscription error:', e);
    }
  }, [currentUser]);

  // 4. Subscribe to Messages for Selected Chat User
  useEffect(() => {
    if (!currentUser || !selectedChatUser) {
      setMessages([]);
      return;
    }

    if (unsubMessagesRef.current) {
      unsubMessagesRef.current();
      unsubMessagesRef.current = null;
    }

    const chatId = getChatId(currentUser.uid, selectedChatUser.uid);
    setMessages([]);

    try {
      const messagesRef = collection(db, 'chats', chatId, 'messages');
      const q = query(messagesRef, orderBy('createdAt', 'asc'));

      const unsub = onSnapshot(
        q,
        (snapshot) => {
          const loadedMsgs: ChatMessage[] = [];
          snapshot.forEach((d) => {
            const data = d.data();
            loadedMsgs.push({
              id: d.id,
              chatId,
              senderId: data.senderId,
              receiverId: data.receiverId,
              text: data.text || '',
              type: data.type || 'text',
              mediaUrl: data.mediaUrl,
              audioDuration: data.audioDuration,
              createdAt: data.createdAt?.toMillis ? data.createdAt.toMillis() : (data.createdAt || Date.now()),
              status: data.status || 'sent',
              reactions: data.reactions
            });
          });
          setMessages(loadedMsgs);
        },
        (err) => {
          console.warn('Firestore messages snapshot error:', err);
        }
      );

      unsubMessagesRef.current = unsub;
    } catch (e) {
      console.warn('Error subscribing to messages:', e);
    }

    return () => {
      if (unsubMessagesRef.current) {
        unsubMessagesRef.current();
      }
    };
  }, [currentUser, selectedChatUser]);

  // Send Message Handler
  const handleSendMessage = async (
    text: string,
    type: MessageType = 'text',
    mediaUrl?: string,
    audioDuration?: number
  ) => {
    if (!currentUser || !selectedChatUser) return;

    const chatId = getChatId(currentUser.uid, selectedChatUser.uid);
    const newMsg: ChatMessage = {
      id: `m_${Date.now()}`,
      chatId,
      senderId: currentUser.uid,
      receiverId: selectedChatUser.uid,
      text,
      type,
      mediaUrl,
      audioDuration,
      createdAt: Date.now(),
      status: 'sent'
    };

    // Optimistically update local message list
    setMessages((prev) => [...prev, newMsg]);

    // Ensure contact is in recent users
    if (!recentChatUsers.some((u) => u.uid === selectedChatUser.uid)) {
      setRecentChatUsers((prev) => [selectedChatUser, ...prev]);
    }

    // Persist to Firestore
    try {
      const chatDocRef = doc(db, 'chats', chatId);
      await setDoc(
        chatDocRef,
        {
          participants: [currentUser.uid, selectedChatUser.uid],
          lastMessage: text,
          lastMessageType: type,
          updatedAt: serverTimestamp()
        },
        { merge: true }
      );

      const msgColRef = collection(db, 'chats', chatId, 'messages');
      await addDoc(msgColRef, {
        senderId: currentUser.uid,
        receiverId: selectedChatUser.uid,
        text,
        type,
        mediaUrl: mediaUrl || '',
        audioDuration: audioDuration || 0,
        createdAt: serverTimestamp(),
        status: 'sent'
      });
    } catch (e) {
      console.warn('Firestore send error, saved in memory session:', e);
    }
  };

  // Start Call Handler
  const handleStartCall = async (type: 'audio' | 'video', targetUser?: UserProfile) => {
    const userToCall = targetUser || selectedChatUser;
    if (!currentUser || !userToCall) return;

    const callId = `call_${Date.now()}`;
    const newSession: CallSession = {
      callId,
      callerId: currentUser.uid,
      callerName: currentUser.name,
      callerAvatar: currentUser.photoURL,
      callerVirtualId: currentUser.virtualId,
      receiverId: userToCall.uid,
      receiverName: userToCall.name,
      receiverAvatar: userToCall.photoURL,
      type,
      status: 'calling',
      startTime: Date.now()
    };

    setActiveCall(newSession);
    showToast(`📞 ${userToCall.name}-কে কল করা হচ্ছে...`);

    try {
      const callDoc = doc(db, 'calls', callId);
      await setDoc(callDoc, {
        ...newSession,
        createdAt: serverTimestamp()
      });
    } catch (e) {
      console.warn('Firestore call record error:', e);
    }
  };

  // Accept Incoming Call
  const handleAcceptIncomingCall = (type: 'audio' | 'video') => {
    if (!incomingCall || !currentUser) return;
    const connectedSession: CallSession = {
      ...incomingCall,
      type,
      status: 'connected'
    };
    setActiveCall(connectedSession);
    setIncomingCall(null);
    sound.stopRingtone();
    sound.playCallConnected();
  };

  // Decline Incoming Call
  const handleDeclineIncomingCall = () => {
    setIncomingCall(null);
    sound.stopRingtone();
    sound.playCallEnded();
    showToast('কল বাতিল করা হয়েছে।');
  };

  // End Active Call
  const handleEndCall = () => {
    setActiveCall(null);
    sound.playCallEnded();
    showToast('কল শেষ হয়েছে।');
  };

  // Search User by Virtual ID
  const handleSearchVirtualId = async (idOrQuery: string) => {
    setSearchError(null);
    setSearchResult(null);

    const clean = idOrQuery.replace(/\s+/g, '').trim();
    if (!clean) return;

    if (clean === currentUser?.virtualId) {
      setSearchError('⚠️ এটি আপনার নিজের ভার্চুয়াল আইডি।');
      return;
    }

    const found = await findUserByVirtualId(clean);
    if (found) {
      setSearchResult(found);
    } else {
      // Partial match in loaded contacts
      const partial = contacts.find(
        (c) =>
          c.virtualId.includes(clean) ||
          c.name.toLowerCase().includes(clean.toLowerCase())
      );
      if (partial) {
        setSearchResult(partial);
      } else {
        setSearchError('❌ এই Virtual ID বা নামের কোনো ব্যবহারকারী পাওয়া যায়নি।');
      }
    }
  };

  // Add Contact by Virtual ID
  const handleAddContact = async (virtualId: string): Promise<boolean> => {
    const cleanId = virtualId.replace(/\s+/g, '').trim();
    if (!cleanId || !currentUser) return false;

    const user = await findUserByVirtualId(cleanId);
    if (user && user.uid !== currentUser.uid) {
      if (!contacts.some((c) => c.uid === user.uid)) {
        setContacts((prev) => [user, ...prev]);
        await addContactToFirestore(currentUser.uid, user.uid);
      }
      return true;
    }
    return false;
  };

  // Add Contact Directly from User Object
  const handleAddContactDirect = async (user: UserProfile) => {
    if (!currentUser || user.uid === currentUser.uid) return;
    if (!contacts.some((c) => c.uid === user.uid)) {
      setContacts((prev) => [user, ...prev]);
      await addContactToFirestore(currentUser.uid, user.uid);
      showToast(`✅ ${user.name} আপনার কন্ট্যাক্টে যুক্ত হয়েছে!`);
    } else {
      showToast(`ℹ️ ${user.name} ইতিমধ্যে আপনার কন্ট্যাক্টে আছে।`);
    }
  };

  // Remove Contact
  const handleRemoveContact = async (uid: string) => {
    if (!currentUser) return;
    setContacts((prev) => prev.filter((c) => c.uid !== uid));
    await removeContactFromFirestore(currentUser.uid, uid);
    showToast('কন্ট্যাক্ট তালিকা থেকে মুছে ফেলা হয়েছে।');
  };

  // Update Profile
  const handleUpdateProfile = (updated: Partial<UserProfile>) => {
    if (!currentUser) return;
    const newProfile = { ...currentUser, ...updated };
    setCurrentUser(newProfile);
    try {
      const userRef = doc(db, 'users', currentUser.uid);
      setDoc(userRef, newProfile, { merge: true });
    } catch (e) {
      console.warn('Profile update error:', e);
    }
    showToast('✅ প্রোফাইল সফলভাবে আপডেট হয়েছে!');
  };

  // Copy ID & Link helpers
  const handleCopyMyId = () => {
    if (!currentUser) return;
    navigator.clipboard.writeText(currentUser.virtualId);
    setCopiedMyId(true);
    setTimeout(() => setCopiedMyId(false), 2000);
    showToast('📋 ভার্চুয়াল আইডি কপি হয়েছে!');
  };

  const handleCopyInviteLink = () => {
    if (!currentUser) return;
    const inviteUrl = `${window.location.origin}/#id=${currentUser.virtualId}`;
    navigator.clipboard.writeText(inviteUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
    showToast('🔗 ইনভাইট লিঙ্ক কপি হয়েছে!');
  };

  // Logout
  const handleLogout = async () => {
    try {
      await fbSignOut(auth);
    } catch {}
    setCurrentUser(null);
    setSelectedChatUser(null);
    setContacts([]);
    setRecentChatUsers([]);
    showToast('👋 লগআউট সম্পন্ন হয়েছে।');
  };

  // 1. Render Splash Screen
  if (showSplash) {
    return <Splash />;
  }

  // 2. Render Auth Screen
  if (!currentUser) {
    return <AuthModal onLoginSuccess={(user) => setCurrentUser(user)} />;
  }

  // Combine recent chat users and contacts for sidebar display without duplicates
  const allSidebarUsersMap = new Map<string, UserProfile>();
  recentChatUsers.forEach((u) => allSidebarUsersMap.set(u.uid, u));
  contacts.forEach((u) => allSidebarUsersMap.set(u.uid, u));
  const sidebarDisplayUsers = Array.from(allSidebarUsersMap.values());

  // 3. Render Main Callora Application
  return (
    <div className="flex h-screen w-screen bg-[#050817] text-slate-100 overflow-hidden font-sans select-none relative">
      {/* Sidebar navigation & direct chats (Adaptive for mobile & desktop) */}
      <div className={`${
        activeTab !== 'chats' || selectedChatUser !== null
          ? 'hidden md:flex md:w-80 lg:w-96 h-full shrink-0'
          : 'w-full md:w-80 lg:w-96 h-full flex shrink-0'
      }`}>
        <Sidebar
          currentUser={currentUser}
          activeTab={activeTab}
          setActiveTab={(tab) => {
            setActiveTab(tab);
            if (tab !== 'chats') {
              setSelectedChatUser(null);
            }
          }}
          selectedChatUser={selectedChatUser}
          onSelectChatUser={(user) => {
            setSelectedChatUser(user);
            setActiveTab('chats');
          }}
          recentUsers={sidebarDisplayUsers}
          onOpenIdCard={() => setShowIdCardModal(true)}
          onSearchVirtualId={handleSearchVirtualId}
          searchResult={searchResult}
          searchError={searchError}
          onLogout={handleLogout}
          onAddContactDirect={handleAddContactDirect}
        />
      </div>

      {/* Main Content View (Routed by ActiveTab) */}
      <main className={`flex-1 flex flex-col h-full overflow-hidden relative ${
        activeTab === 'chats' && !selectedChatUser ? 'hidden md:flex' : 'flex'
      }`}>
        {activeTab === 'chats' && selectedChatUser && (
          <ChatView
            currentUser={currentUser}
            selectedUser={selectedChatUser}
            messages={messages}
            onSendMessage={handleSendMessage}
            onStartCall={(type) => handleStartCall(type)}
            onOpenUserProfile={() => setShowIdCardModal(true)}
            onBack={() => setSelectedChatUser(null)}
          />
        )}

        {/* Clean, Unique Welcome Hub when no user is contacted or selected */}
        {activeTab === 'chats' && !selectedChatUser && (
          <div className="flex-1 flex flex-col items-center justify-center p-6 lg:p-12 text-center bg-gradient-to-b from-[#060a1d] via-[#050817] to-[#040612] overflow-y-auto">
            <div className="max-w-xl mx-auto w-full space-y-6">
              {/* Glowing Holographic Badge */}
              <div className="relative inline-block">
                <div className="w-24 h-24 rounded-3xl bg-gradient-to-tr from-cyan-500 via-indigo-600 to-fuchsia-500 p-0.5 shadow-[0_0_60px_rgba(0,217,255,0.25)] mx-auto">
                  <div className="w-full h-full bg-[#080d24] rounded-[22px] flex items-center justify-center">
                    <MessageSquare className="w-12 h-12 text-cyan-400" />
                  </div>
                </div>
                <span className="absolute -top-1 -right-1 flex h-4 w-4">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-4 w-4 bg-cyan-500"></span>
                </span>
              </div>

              <div>
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/70 border border-cyan-400/30 text-cyan-300 text-xs font-bold uppercase tracking-wider mb-2">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Callora Secure Network Active</span>
                </div>
                <h2 className="text-3xl font-black text-white tracking-tight">
                  স্বাগতম, {currentUser.name}!
                </h2>
                <p className="text-xs sm:text-sm text-slate-400 mt-2 leading-relaxed">
                  ফোন নম্বর ছাড়াই আপনার ব্যক্তিগত <strong className="text-cyan-300">১১-সংখ্যার Virtual ID</strong> দিয়ে যেকোনো সময় ফুল-এনক্রিপ্টেড অডিও কল, HD ভিডিও কল এবং মেসেজিং করুন।
                </p>
              </div>

              {/* Virtual ID Card Pill */}
              <div className="p-5 rounded-2xl bg-[#0c1228] border border-cyan-500/30 shadow-xl space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400 font-medium">আপনার ব্যক্তিগত Virtual ID:</span>
                  <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Active Pass</span>
                  </span>
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-[#111735] border border-slate-700 font-mono text-cyan-300 text-lg sm:text-xl font-black tracking-widest">
                  <span>{formatVirtualId(currentUser.virtualId)}</span>
                  <button
                    onClick={handleCopyMyId}
                    className="p-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500 text-cyan-300 hover:text-slate-950 transition-all cursor-pointer"
                    title="Copy Virtual ID"
                  >
                    {copiedMyId ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                  </button>
                </div>

                {/* Action Buttons */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                  <button
                    onClick={handleCopyInviteLink}
                    className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold flex items-center justify-center gap-2 border border-slate-700 transition-all cursor-pointer"
                  >
                    {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5 text-cyan-400" />}
                    <span>{copiedLink ? 'কপি হয়েছে' : 'ইনভাইট লিঙ্ক'}</span>
                  </button>

                  <button
                    onClick={() => setShowIdCardModal(true)}
                    className="py-2.5 px-3 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 transition-all cursor-pointer"
                  >
                    <QrCode className="w-3.5 h-3.5" />
                    <span>ID কার্ড দেখুন</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('contacts')}
                    className="py-2.5 px-3 rounded-xl bg-[#151d40] hover:bg-[#1a2552] text-cyan-300 text-xs font-bold flex items-center justify-center gap-2 border border-cyan-500/30 transition-all cursor-pointer"
                  >
                    <UserPlus className="w-3.5 h-3.5 text-cyan-400" />
                    <span>কন্ট্যাক্ট যোগ করুন</span>
                  </button>
                </div>
              </div>

              {/* Quick AI Assistant Card */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-purple-950/40 via-[#101438] to-cyan-950/40 border border-purple-500/20 flex items-center justify-between text-left">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-purple-900/60 border border-purple-500/30 flex items-center justify-center text-purple-300 shrink-0">
                    <Bot className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">Callora AI Assistant</h4>
                    <p className="text-[11px] text-slate-400">মেসেজ ড্রাফট, অনুবাদ বা সাহায্য নিতে AI ট্রাই করুন</p>
                  </div>
                </div>

                <button
                  onClick={() => setActiveTab('ai')}
                  className="px-3 py-1.5 rounded-lg bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold transition-all cursor-pointer shrink-0"
                >
                  ওপেন AI
                </button>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'contacts' && (
          <ContactsView
            currentUser={currentUser}
            contacts={contacts}
            onSelectChatUser={(user) => {
              setSelectedChatUser(user);
              setActiveTab('chats');
            }}
            onStartCall={(user, type) => handleStartCall(type, user)}
            onOpenIdCard={() => setShowIdCardModal(true)}
            onAddContact={handleAddContact}
            onRemoveContact={handleRemoveContact}
          />
        )}

        {activeTab === 'groups' && (
          <GroupsView
            currentUser={currentUser}
            contacts={contacts}
            onOpenGroupChat={(group) => {
              setActiveGroup(group);
              showToast(`💬 "${group.name}" গ্রুপে প্রবেশ করেছেন।`);
            }}
            onStartGroupCall={(group, type) => {
              handleStartCall(type);
              showToast(`📞 "${group.name}" গ্রুপ কনফারেন্স শুরু হচ্ছে...`);
            }}
          />
        )}

        {activeTab === 'ai' && <AIView />}

        {activeTab === 'settings' && (
          <SettingsView
            currentUser={currentUser}
            onUpdateProfile={handleUpdateProfile}
            onOpenIdCard={() => setShowIdCardModal(true)}
            onLogout={handleLogout}
          />
        )}
      </main>

      {/* Mobile Bottom Navigation Bar (Visible on mobile when not inside an active 1-on-1 chat) */}
      {!(activeTab === 'chats' && selectedChatUser) && (
        <nav className="md:hidden fixed bottom-0 left-0 right-0 h-16 bg-[#080d22]/95 backdrop-blur-xl border-t border-slate-800/90 z-40 px-2 flex items-center justify-around">
          <button
            onClick={() => {
              setSelectedChatUser(null);
              setActiveTab('chats');
            }}
            className={`flex flex-col items-center justify-center w-14 h-12 rounded-xl transition-all cursor-pointer ${
              activeTab === 'chats'
                ? 'text-cyan-400 font-bold bg-cyan-950/60 border border-cyan-500/30 shadow-lg shadow-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <MessageSquare className="w-5 h-5" />
            <span className="text-[10px] mt-0.5">চ্যাট</span>
          </button>

          <button
            onClick={() => {
              setSelectedChatUser(null);
              setActiveTab('contacts');
            }}
            className={`flex flex-col items-center justify-center w-14 h-12 rounded-xl transition-all cursor-pointer ${
              activeTab === 'contacts'
                ? 'text-cyan-400 font-bold bg-cyan-950/60 border border-cyan-500/30 shadow-lg shadow-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Users className="w-5 h-5" />
            <span className="text-[10px] mt-0.5">কন্ট্যাক্ট</span>
          </button>

          <button
            onClick={() => {
              setSelectedChatUser(null);
              setActiveTab('groups');
            }}
            className={`flex flex-col items-center justify-center w-14 h-12 rounded-xl transition-all cursor-pointer ${
              activeTab === 'groups'
                ? 'text-cyan-400 font-bold bg-cyan-950/60 border border-cyan-500/30 shadow-lg shadow-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <MessagesSquare className="w-5 h-5" />
            <span className="text-[10px] mt-0.5">গ্রুপ</span>
          </button>

          <button
            onClick={() => {
              setSelectedChatUser(null);
              setActiveTab('ai');
            }}
            className={`flex flex-col items-center justify-center w-14 h-12 rounded-xl transition-all relative cursor-pointer ${
              activeTab === 'ai'
                ? 'text-purple-300 font-bold bg-purple-950/60 border border-purple-500/40 shadow-lg shadow-purple-500/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bot className="w-5 h-5" />
            <span className="text-[10px] mt-0.5">AI</span>
            <span className="absolute top-1.5 right-2.5 w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          </button>

          <button
            onClick={() => {
              setSelectedChatUser(null);
              setActiveTab('settings');
            }}
            className={`flex flex-col items-center justify-center w-14 h-12 rounded-xl transition-all cursor-pointer ${
              activeTab === 'settings'
                ? 'text-cyan-400 font-bold bg-cyan-950/60 border border-cyan-500/30 shadow-lg shadow-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Settings className="w-5 h-5" />
            <span className="text-[10px] mt-0.5">সেটিংস</span>
          </button>
        </nav>
      )}

      {/* WebRTC Audio & Video Call Modal + Incoming Call Ringing Interface */}
      <CallModal
        currentUser={currentUser}
        activeCall={activeCall}
        incomingCall={incomingCall}
        onAcceptIncoming={handleAcceptIncomingCall}
        onDeclineIncoming={handleDeclineIncomingCall}
        onEndCall={handleEndCall}
      />

      {/* Holographic Virtual ID Card Modal */}
      <VirtualIdCardModal
        user={currentUser}
        isOpen={showIdCardModal}
        onClose={() => setShowIdCardModal(false)}
      />

      {/* Global Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 px-4 py-2.5 rounded-xl bg-[#12193b] border border-cyan-500/40 text-cyan-200 text-xs font-semibold shadow-2xl shadow-cyan-500/20 flex items-center gap-2 animate-in slide-in-from-bottom-4 pointer-events-none">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
