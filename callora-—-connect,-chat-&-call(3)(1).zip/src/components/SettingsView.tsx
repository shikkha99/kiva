import React, { useState, useRef } from 'react';
import {
  User,
  Camera,
  Upload,
  Image as ImageIcon,
  Sparkles,
  QrCode,
  Copy,
  Check,
  Save,
  Volume2,
  VolumeX,
  Shield,
  ShieldCheck,
  Lock,
  Smartphone,
  LogOut,
  Radio,
  RefreshCw,
  Trash2,
  Sliders,
  Palette,
  Bell,
  BellOff,
  Music,
  Zap,
  Eye,
  EyeOff,
  Globe,
  HardDrive,
  Share2,
  ChevronRight,
  Smile
} from 'lucide-react';
import { UserProfile } from '../types';
import { formatVirtualId, getInitials } from '../services/firebase';
import { sound } from '../services/sound';

interface SettingsViewProps {
  currentUser: UserProfile;
  onUpdateProfile: (updated: Partial<UserProfile>) => void;
  onOpenIdCard: () => void;
  onLogout: () => void;
}

// Preset Cyber Avatars
const PRESET_AVATARS = [
  { id: 'cyber_ninja', label: 'Cyber Ninja', icon: '🥷', bg: 'from-cyan-500 to-blue-600' },
  { id: 'quantum_ai', label: 'Quantum AI', icon: '🤖', bg: 'from-purple-600 to-indigo-700' },
  { id: 'cyber_girl', label: 'Cyber Pulse', icon: '⚡', bg: 'from-fuchsia-500 to-pink-600' },
  { id: 'astro_voyager', label: 'Astro Pilot', icon: '🚀', bg: 'from-blue-600 to-indigo-900' },
  { id: 'synth_samurai', label: 'Synth Warrior', icon: '⚔️', bg: 'from-amber-500 to-rose-600' },
  { id: 'hologram_cat', label: 'Cyber Cat', icon: '🐱', bg: 'from-teal-400 to-cyan-600' },
  { id: 'matrix_hacker', label: 'Ghost Runner', icon: '🕶️', bg: 'from-emerald-500 to-teal-700' },
  { id: 'crypto_fire', label: 'Solar Flame', icon: '🔥', bg: 'from-orange-500 to-red-600' },
  { id: 'quantum_crown', label: 'Cyber King', icon: '👑', bg: 'from-violet-600 to-purple-900' },
  { id: 'star_spark', label: 'Cosmic Star', icon: '🌟', bg: 'from-yellow-400 to-amber-600' }
];

// Preset Gradients for Monograms
const PRESET_GRADIENTS = [
  { id: 'cyan_blue', name: 'Cyber Neon', class: 'from-cyan-500 to-blue-600', ring: 'ring-cyan-400' },
  { id: 'purple_fuchsia', name: 'Synthwave', class: 'from-purple-600 to-fuchsia-600', ring: 'ring-fuchsia-400' },
  { id: 'emerald_teal', name: 'Matrix Green', class: 'from-emerald-500 to-teal-600', ring: 'ring-emerald-400' },
  { id: 'amber_sunset', name: 'Solar Flare', class: 'from-amber-500 to-orange-600', ring: 'ring-amber-400' },
  { id: 'rose_crimson', name: 'Crimson Pulse', class: 'from-rose-500 to-red-600', ring: 'ring-rose-400' },
  { id: 'indigo_violet', name: 'Deep Void', class: 'from-indigo-600 to-violet-700', ring: 'ring-indigo-400' },
  { id: 'teal_emerald', name: 'Arctic Aurora', class: 'from-teal-400 to-emerald-600', ring: 'ring-teal-400' },
  { id: 'pink_purple', name: 'Galactic Magenta', class: 'from-pink-500 to-purple-700', ring: 'ring-pink-400' }
];

// Quick Status Chips
const QUICK_STATUSES = [
  '🟢 অ্যাক্টিভ ও কল করার জন্য প্রস্তুত',
  '💻 কোডিং ও কাজে ব্যস্ত 🚀',
  '🎧 ইনকামিং কলে আছি',
  '⚡ সাইবার মোড সক্রিয়',
  '🌙 বিরতিতে আছি (DND)',
  '✨ Callora ভার্চুয়াল নেটওয়ার্কে যুক্ত'
];

export const SettingsView: React.FC<SettingsViewProps> = ({
  currentUser,
  onUpdateProfile,
  onOpenIdCard,
  onLogout
}) => {
  const [name, setName] = useState(currentUser.name);
  const [username, setUsername] = useState(currentUser.username || '');
  const [statusText, setStatusText] = useState(currentUser.statusText || 'Available on Callora 🟢');
  const [bio, setBio] = useState(currentUser.bio || '');
  const [currentPhoto, setCurrentPhoto] = useState<string | undefined>(currentUser.photoURL);
  const [avatarBg, setAvatarBg] = useState<string>(currentUser.avatarBg || 'from-cyan-500 to-blue-600');
  
  // Tabs within settings
  const [activeSettingsSection, setActiveSettingsSection] = useState<'profile' | 'avatar' | 'sound' | 'security' | 'storage'>('profile');

  // Audio toggles & testing
  const [isSoundMuted, setIsSoundMuted] = useState(false);
  const [ringtoneTesting, setRingtoneTesting] = useState(false);

  // Privacy toggles
  const [showLastSeen, setShowLastSeen] = useState(true);
  const [allowDirectCalls, setAllowDirectCalls] = useState(true);
  const [readReceipts, setReadReceipts] = useState(true);

  // UI state
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [copiedId, setCopiedId] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [cacheCleared, setCacheCleared] = useState(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Handle Photo Upload with HTML5 Canvas Compression
  const handlePhotoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new window.Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const MAX_SIZE = 320;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_SIZE) {
            height = Math.round((height * MAX_SIZE) / width);
            width = MAX_SIZE;
          }
        } else {
          if (height > MAX_SIZE) {
            width = Math.round((width * MAX_SIZE) / height);
            height = MAX_SIZE;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.85);
          setCurrentPhoto(compressedDataUrl);
        }
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  // Remove photo and switch to initial/gradient avatar
  const handleRemovePhoto = () => {
    setCurrentPhoto(undefined);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  // Save changes to profile
  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateProfile({
      name: name.trim() || currentUser.name,
      username: username.trim() || undefined,
      statusText: statusText.trim(),
      bio: bio.trim(),
      photoURL: currentPhoto,
      avatarBg: avatarBg
    });

    setSavedSuccess(true);
    sound.playMessageSent();
    setTimeout(() => setSavedSuccess(false), 3000);
  };

  // Audio Testing Controls
  const toggleSound = () => {
    const next = !isSoundMuted;
    setIsSoundMuted(next);
    sound.setMuted(next);
  };

  const handleTestRingtone = () => {
    if (ringtoneTesting) {
      sound.stopRingtone();
      setRingtoneTesting(false);
    } else {
      sound.startIncomingRingtone();
      setRingtoneTesting(true);
      setTimeout(() => {
        sound.stopRingtone();
        setRingtoneTesting(false);
      }, 4000);
    }
  };

  const handleTestChime = () => {
    sound.playMessageSent();
  };

  const handleTestCallChime = () => {
    sound.playCallConnected();
  };

  // Copy ID & Invite Link
  const handleCopyId = () => {
    navigator.clipboard.writeText(currentUser.virtualId);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const handleCopyInviteLink = () => {
    const inviteUrl = `${window.location.origin}/#id=${currentUser.virtualId}`;
    navigator.clipboard.writeText(inviteUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // Clear local cache
  const handleClearCache = () => {
    try {
      localStorage.removeItem('callora_temp_cache');
    } catch {}
    setCacheCleared(true);
    setTimeout(() => setCacheCleared(false), 2500);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#050817] p-3 sm:p-6 lg:p-8 overflow-y-auto select-none pb-24 md:pb-8">
      <div className="max-w-3xl mx-auto w-full space-y-5 sm:space-y-6">
        
        {/* Top Header Card */}
        <div className="bg-gradient-to-r from-[#0c1433] via-[#0e173b] to-[#161a45] p-5 sm:p-6 rounded-3xl border border-cyan-500/20 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/70 border border-cyan-400/30 text-cyan-300 text-xs font-semibold uppercase tracking-wider mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Callora User Settings</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white">প্রোফাইল ও অ্যাপ সেটিংস</h2>
            <p className="text-xs text-slate-400 mt-1">
              প্রোফাইল ছবি পরিবর্তন, ভার্চুয়াল আইডি ও নিরাপত্তা অপশন সাজিয়ে নিন
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenIdCard}
              className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25 transition-all cursor-pointer"
            >
              <QrCode className="w-4 h-4" />
              <span>ID পাস কার্ড</span>
            </button>
            <button
              onClick={handleCopyInviteLink}
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs font-bold flex items-center justify-center transition-all cursor-pointer"
              title="ইনভাইট লিঙ্ক কপি করুন"
            >
              {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4 text-cyan-400" />}
            </button>
          </div>
        </div>

        {/* Settings Navigation Tabs */}
        <div className="flex items-center gap-1.5 p-1.5 bg-[#0c1228] border border-slate-800 rounded-2xl overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveSettingsSection('profile')}
            className={`flex-1 min-w-[100px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeSettingsSection === 'profile'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>প্রোফাইল</span>
          </button>

          <button
            onClick={() => setActiveSettingsSection('avatar')}
            className={`flex-1 min-w-[100px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeSettingsSection === 'avatar'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <Palette className="w-3.5 h-3.5" />
            <span>ফটো ও অ্যাভাটার</span>
          </button>

          <button
            onClick={() => setActiveSettingsSection('sound')}
            className={`flex-1 min-w-[100px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeSettingsSection === 'sound'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>সাউন্ড ও কল</span>
          </button>

          <button
            onClick={() => setActiveSettingsSection('security')}
            className={`flex-1 min-w-[100px] py-2.5 px-3 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeSettingsSection === 'security'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md shadow-cyan-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <Shield className="w-3.5 h-3.5" />
            <span>সিকিউরিটি</span>
          </button>
        </div>

        {/* Section 1: Personal Details & ID Card Info */}
        {activeSettingsSection === 'profile' && (
          <form onSubmit={handleSaveProfile} className="bg-[#0c1228] p-5 sm:p-6 rounded-3xl border border-slate-800 space-y-5 shadow-lg">
            {/* Live Profile Card Preview */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-[#111838] to-[#0d1430] border border-cyan-500/20 flex flex-col sm:flex-row items-center sm:items-start gap-4">
              <div className="relative group">
                {currentPhoto ? (
                  <img
                    src={currentPhoto}
                    alt={name}
                    className="w-20 h-20 rounded-2xl object-cover ring-4 ring-cyan-400/40 shadow-xl"
                  />
                ) : (
                  <div className={`w-20 h-20 rounded-2xl bg-gradient-to-br ${avatarBg} flex items-center justify-center text-3xl font-black text-white ring-4 ring-cyan-400/40 shadow-xl`}>
                    {getInitials(name)}
                  </div>
                )}
                
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute -bottom-1 -right-1 p-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-lg border border-[#0c1228] transition-all cursor-pointer"
                  title="ছবি আপলোড করুন"
                >
                  <Camera className="w-4 h-4" />
                </button>
              </div>

              <div className="flex-1 text-center sm:text-left min-w-0">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                  <h3 className="text-base sm:text-lg font-bold text-white truncate">{name}</h3>
                  <span className="text-xs text-emerald-400 font-semibold flex items-center justify-center sm:justify-start gap-1">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    <span>Active Now</span>
                  </span>
                </div>

                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mt-1.5">
                  <span className="text-xs text-cyan-300 font-mono bg-cyan-950/80 px-2.5 py-0.5 rounded-md border border-cyan-500/30">
                    {formatVirtualId(currentUser.virtualId)}
                  </span>
                  <button
                    type="button"
                    onClick={handleCopyId}
                    className="p-1 hover:text-cyan-300 text-slate-400 cursor-pointer"
                    title="Copy Virtual ID"
                  >
                    {copiedId ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>

                <p className="text-xs text-slate-300 mt-2 italic bg-[#0a0f26] p-2 rounded-xl border border-slate-800 inline-block">
                  "{statusText || 'Available on Callora 🟢'}"
                </p>
              </div>
            </div>

            {/* Input Fields */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  আপনার নাম (Display Name)
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="যেমন: Sabbir Ahmed"
                  className="w-full px-4 py-2.5 bg-[#111735] border border-slate-700 rounded-xl text-white placeholder-slate-500 text-xs focus:outline-none focus:border-cyan-400 transition-colors"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  ইউজারনেম (Username / Handle)
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-cyan-400 font-mono text-xs">@</span>
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value.replace(/[^a-zA-Z0-9_]/g, ''))}
                    placeholder="sabbir21"
                    className="w-full pl-8 pr-4 py-2.5 bg-[#111735] border border-slate-700 rounded-xl text-white placeholder-slate-500 text-xs focus:outline-none focus:border-cyan-400 font-mono transition-colors"
                  />
                </div>
              </div>
            </div>

            {/* Status Field with Quick Presets */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                কাস্টম স্ট্যাটাস মেসেজ
              </label>
              <input
                type="text"
                value={statusText}
                onChange={(e) => setStatusText(e.target.value)}
                placeholder="যেমন: Coding on Callora 🚀"
                className="w-full px-4 py-2.5 bg-[#111735] border border-slate-700 rounded-xl text-white placeholder-slate-500 text-xs focus:outline-none focus:border-cyan-400 transition-colors"
              />

              <div className="mt-2.5">
                <span className="text-[11px] text-slate-400 block mb-1.5 font-medium">কুইক স্ট্যাটাস সিলেক্ট করুন:</span>
                <div className="flex flex-wrap gap-1.5">
                  {QUICK_STATUSES.map((qs) => (
                    <button
                      key={qs}
                      type="button"
                      onClick={() => setStatusText(qs)}
                      className={`text-[11px] px-2.5 py-1 rounded-lg border transition-all cursor-pointer ${
                        statusText === qs
                          ? 'bg-cyan-500 text-slate-950 font-bold border-cyan-400'
                          : 'bg-[#111735] text-slate-300 border-slate-700 hover:border-cyan-500/50'
                      }`}
                    >
                      {qs}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Bio Field */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                বায়ো / সংক্ষিপ্ত পরিচিতি (Bio)
              </label>
              <textarea
                rows={3}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                placeholder="আপনার সম্পর্কে কিছু লিখুন... (যেমন: Tech enthusiast & Callora user)"
                className="w-full px-4 py-2.5 bg-[#111735] border border-slate-700 rounded-xl text-white placeholder-slate-500 text-xs focus:outline-none focus:border-cyan-400 transition-colors"
              />
            </div>

            {/* Submit Bar */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-800">
              {savedSuccess ? (
                <span className="text-xs text-emerald-400 font-bold flex items-center gap-1.5 animate-in fade-in">
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span>প্রোফাইল সফলভাবে আপডেট হয়েছে!</span>
                </span>
              ) : (
                <span className="text-[11px] text-slate-500">পরিবর্তন করতে "সংরক্ষণ করুন" বাটনে চাপুন</span>
              )}

              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-cyan-500/25 transition-all cursor-pointer active:scale-95"
              >
                <Save className="w-4 h-4" />
                <span>সংরক্ষণ করুন</span>
              </button>
            </div>
          </form>
        )}

        {/* Section 2: Avatar & Profile Photo Studio */}
        {activeSettingsSection === 'avatar' && (
          <div className="bg-[#0c1228] p-5 sm:p-6 rounded-3xl border border-slate-800 space-y-6 shadow-lg">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Camera className="w-5 h-5 text-cyan-400" />
                <span>প্রোফাইল পিকচার স্টুডিও</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                আপনার ডিভাইস থেকে যেকোনো ফটো আপলোড করুন অথবা সাইবার অ্যাভাটার ও গ্রেডিয়েন্ট থিম নির্বাচন করুন
              </p>
            </div>

            {/* Hidden File Input */}
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              onChange={handlePhotoUpload}
              className="hidden"
            />

            {/* Upload Area */}
            <div className="p-5 rounded-2xl bg-[#111735] border-2 border-dashed border-cyan-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <div className="relative shrink-0">
                  {currentPhoto ? (
                    <img
                      src={currentPhoto}
                      alt="Avatar"
                      className="w-16 h-16 rounded-2xl object-cover ring-2 ring-cyan-400"
                    />
                  ) : (
                    <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${avatarBg} flex items-center justify-center text-2xl font-black text-white ring-2 ring-cyan-400`}>
                      {getInitials(name)}
                    </div>
                  )}
                </div>

                <div>
                  <h4 className="text-sm font-bold text-white">কাস্টম ছবি যুক্ত করুন</h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    JPG, PNG বা WebP ফরম্যাট (স্বয়ংক্রিয়ভাবে অপ্টিমাইজড হবে)
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="flex-1 sm:flex-initial px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-md transition-all cursor-pointer"
                >
                  <Upload className="w-4 h-4" />
                  <span>ফাইল বেছে নিন</span>
                </button>

                {currentPhoto && (
                  <button
                    type="button"
                    onClick={handleRemovePhoto}
                    className="p-2.5 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/40 text-xs font-bold transition-colors cursor-pointer"
                    title="ছবি রিমুভ করুন"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Gradient Theme Selector for Initials Monogram */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2 flex items-center gap-2">
                <Palette className="w-4 h-4 text-cyan-400" />
                <span>অ্যাভাটার গ্রেডিয়েন্ট থিম নির্বাচন করুন</span>
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {PRESET_GRADIENTS.map((grad) => (
                  <button
                    key={grad.id}
                    type="button"
                    onClick={() => {
                      setAvatarBg(grad.class);
                      if (currentPhoto) {
                        setCurrentPhoto(undefined);
                      }
                    }}
                    className={`p-2.5 rounded-xl bg-[#111735] border flex items-center gap-2.5 transition-all cursor-pointer ${
                      avatarBg === grad.class && !currentPhoto
                        ? 'border-cyan-400 shadow-md shadow-cyan-500/20 ring-1 ring-cyan-400'
                        : 'border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className={`w-7 h-7 rounded-lg bg-gradient-to-br ${grad.class} flex items-center justify-center text-xs font-bold text-white shadow-inner`}>
                      {getInitials(name)}
                    </div>
                    <span className="text-xs font-medium text-white truncate">{grad.name}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Cyberpunk Preset Badges */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-2 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span>সাইবার ও ফিউচারিস্টিক প্রিসেট অ্যাভাটার</span>
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
                {PRESET_AVATARS.map((av) => (
                  <button
                    key={av.id}
                    type="button"
                    onClick={() => {
                      setAvatarBg(av.bg);
                      setCurrentPhoto(undefined);
                    }}
                    className="p-3 rounded-2xl bg-[#111735] hover:bg-[#162047] border border-slate-800 hover:border-cyan-500/40 flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer group"
                  >
                    <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${av.bg} flex items-center justify-center text-2xl shadow-md group-hover:scale-105 transition-transform`}>
                      {av.icon}
                    </div>
                    <span className="text-[11px] font-bold text-slate-300 group-hover:text-white truncate">
                      {av.label}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Save Button */}
            <div className="pt-3 border-t border-slate-800 flex justify-end">
              <button
                type="button"
                onClick={handleSaveProfile}
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-cyan-500/25 transition-all cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>অ্যাভাটার সেভ করুন</span>
              </button>
            </div>
          </div>
        )}

        {/* Section 3: Sound & Call FX Studio */}
        {activeSettingsSection === 'sound' && (
          <div className="bg-[#0c1228] p-5 sm:p-6 rounded-3xl border border-slate-800 space-y-5 shadow-lg">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Volume2 className="w-5 h-5 text-cyan-400" />
                <span>অ্যাপ সাউন্ড ও অডিও ইঞ্জিন</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                কল রিংটোন, চিম নোটিফিকেশন এবং সাউন্ড এফেক্ট টেস্ট করুন
              </p>
            </div>

            {/* Mute Master Switch */}
            <div className="flex items-center justify-between p-4 rounded-2xl bg-[#111735] border border-slate-800">
              <div>
                <p className="text-xs font-bold text-white">মাস্টার অডিও সুইচ</p>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  কল এলে রিংটোন ও মেসেজ সেন্ডিং সাউন্ড চালু থাকবে কি না
                </p>
              </div>

              <button
                onClick={toggleSound}
                className={`px-4 py-2 rounded-xl border flex items-center gap-2 text-xs font-bold transition-all cursor-pointer ${
                  isSoundMuted
                    ? 'bg-rose-950/50 border-rose-600/40 text-rose-300'
                    : 'bg-emerald-950/50 border-emerald-600/40 text-emerald-300 shadow-lg shadow-emerald-500/10'
                }`}
              >
                {isSoundMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                <span>{isSoundMuted ? 'নিঃশব্দ (Muted)' : 'সাউন্ড সক্রিয় (On)'}</span>
              </button>
            </div>

            {/* Interactive Sound Test Board */}
            <div className="p-4 rounded-2xl bg-[#0e142e] border border-cyan-500/20 space-y-3">
              <h4 className="text-xs font-bold text-cyan-300 flex items-center gap-1.5">
                <Music className="w-4 h-4 text-cyan-400" />
                <span>ইন্টারেক্টিভ সাউন্ড টেস্ট বোর্ড</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                <button
                  type="button"
                  onClick={handleTestRingtone}
                  className={`p-3 rounded-xl border flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer ${
                    ringtoneTesting
                      ? 'bg-rose-950/80 border-rose-500 text-rose-300 animate-pulse'
                      : 'bg-[#12193b] border-slate-700 text-cyan-300 hover:bg-cyan-500 hover:text-slate-950'
                  }`}
                >
                  <Bell className="w-4 h-4" />
                  <span>{ringtoneTesting ? 'রিংটোন থামান ⏹️' : 'রিংটোন টেস্ট ▶️'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleTestChime}
                  className="p-3 rounded-xl bg-[#12193b] hover:bg-cyan-500 hover:text-slate-950 text-cyan-300 border border-slate-700 flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer"
                >
                  <Zap className="w-4 h-4" />
                  <span>মেসেজ চিম টেস্ট 🔔</span>
                </button>

                <button
                  type="button"
                  onClick={handleTestCallChime}
                  className="p-3 rounded-xl bg-[#12193b] hover:bg-cyan-500 hover:text-slate-950 text-cyan-300 border border-slate-700 flex items-center justify-center gap-2 text-xs font-bold transition-all cursor-pointer"
                >
                  <Radio className="w-4 h-4" />
                  <span>কল কানেক্ট টিউন 🎵</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Section 4: Security, Privacy & WebRTC DTLS/SRTP */}
        {activeSettingsSection === 'security' && (
          <div className="bg-[#0c1228] p-5 sm:p-6 rounded-3xl border border-slate-800 space-y-5 shadow-lg">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <span>নিরাপত্তা ও এন্ড-টু-এন্ড এনক্রিপশন</span>
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                আপনার গোপনীয়তা ও নিরাপদ কলিং প্যারামিটার
              </p>
            </div>

            <div className="space-y-3">
              {/* WebRTC Status */}
              <div className="flex items-center justify-between p-4 rounded-2xl bg-[#111735] border border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-950/60 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                    <Lock className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-white">DTLS / SRTP ফুল এনক্রিপশন</h4>
                    <p className="text-[11px] text-slate-400">কলরা সার্ভারে কোনো অডিও বা ভিডিও রেকর্ড সংরক্ষিত হয় না</p>
                  </div>
                </div>
                <span className="text-xs text-emerald-400 font-bold bg-emerald-950/80 px-2.5 py-1 rounded-lg border border-emerald-500/30">
                  সক্রিয় (Active)
                </span>
              </div>

              {/* Direct Calls Allowed */}
              <div className="flex items-center justify-between p-4 rounded-2xl bg-[#111735] border border-slate-800">
                <div>
                  <h4 className="text-xs font-bold text-white">সরাসরি ভার্চুয়াল আইডি কল গ্রহণ</h4>
                  <p className="text-[11px] text-slate-400">যেকোনো কলরা ইউজার আপনাকে ১১-সংখ্যার আইডি দিয়ে কল দিতে পারবে</p>
                </div>
                <button
                  type="button"
                  onClick={() => setAllowDirectCalls(!allowDirectCalls)}
                  className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                    allowDirectCalls ? 'bg-cyan-500' : 'bg-slate-700'
                  }`}
                >
                  <span className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                    allowDirectCalls ? 'right-1' : 'left-1'
                  }`} />
                </button>
              </div>

              {/* Last Seen visibility */}
              <div className="flex items-center justify-between p-4 rounded-2xl bg-[#111735] border border-slate-800">
                <div>
                  <h4 className="text-xs font-bold text-white">অনলাইন স্ট্যাটাস ও লাস্ট সিন প্রদর্শন</h4>
                  <p className="text-[11px] text-slate-400">আপনার সক্রিয় থাকার সময় অন্যান্য কন্ট্যাক্ট দেখতে পাবে</p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowLastSeen(!showLastSeen)}
                  className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                    showLastSeen ? 'bg-cyan-500' : 'bg-slate-700'
                  }`}
                >
                  <span className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform ${
                    showLastSeen ? 'right-1' : 'left-1'
                  }`} />
                </button>
              </div>

              {/* Cache Management */}
              <div className="flex items-center justify-between p-4 rounded-2xl bg-[#111735] border border-slate-800">
                <div>
                  <h4 className="text-xs font-bold text-white">লোকাল ক্যাশ ও ফাইল মেমোরি</h4>
                  <p className="text-[11px] text-slate-400">টেম্পোরারি ফাইল মেমরি পরিষ্কার করে অ্যাপ দ্রুত রাখুন</p>
                </div>
                <button
                  type="button"
                  onClick={handleClearCache}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-cyan-300 text-xs font-bold flex items-center gap-1.5 border border-slate-700 cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>{cacheCleared ? 'পরিষ্কার হয়েছে!' : 'ক্যাশ ক্লিয়ার'}</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Logout Action Bar */}
        <div className="p-4 rounded-2xl bg-[#0c1228] border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h4 className="text-xs font-bold text-white">অ্যাকাউন্ট থেকে প্রস্থান</h4>
            <p className="text-[11px] text-slate-400">বর্তমান ডিভাইস থেকে সাইন-আউট করতে নিচের বাটনে চাপুন</p>
          </div>

          <button
            onClick={onLogout}
            className="py-2.5 px-5 rounded-xl bg-rose-950/40 hover:bg-rose-900/60 text-rose-300 border border-rose-800/40 font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
          >
            <LogOut className="w-4 h-4" />
            <span>লগআউট করুন</span>
          </button>
        </div>

      </div>
    </div>
  );
};
