import React, { useState, useRef, useEffect } from 'react';
import {
  Phone,
  Video,
  Send,
  Smile,
  Paperclip,
  Mic,
  MicOff,
  Image as ImageIcon,
  MoreVertical,
  Check,
  CheckCheck,
  Sparkles,
  Play,
  Pause,
  Copy,
  Trash2,
  CornerUpLeft,
  X,
  Volume2,
  MessageSquare,
  ChevronLeft
} from 'lucide-react';
import { UserProfile, ChatMessage, MessageType } from '../types';
import { formatVirtualId, getInitials, formatTimestamp } from '../services/firebase';
import { sound } from '../services/sound';
import { getSmartReplySuggestions } from '../services/gemini';

interface ChatViewProps {
  currentUser: UserProfile;
  selectedUser: UserProfile;
  messages: ChatMessage[];
  onSendMessage: (text: string, type?: MessageType, mediaUrl?: string, audioDuration?: number) => void;
  onStartCall: (type: 'audio' | 'video') => void;
  onReactMessage?: (messageId: string, emoji: string) => void;
  onOpenUserProfile?: () => void;
  onBack?: () => void;
}

export const ChatView: React.FC<ChatViewProps> = ({
  currentUser,
  selectedUser,
  messages,
  onSendMessage,
  onStartCall,
  onReactMessage,
  onOpenUserProfile,
  onBack
}) => {
  const [inputText, setInputText] = useState('');
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [isRecordingVoice, setIsRecordingVoice] = useState(false);
  const [recordingSeconds, setRecordingSeconds] = useState(0);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);
  const [replyingTo, setReplyingTo] = useState<ChatMessage | null>(null);
  const [selectedImageModal, setSelectedImageModal] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const recordingTimerRef = useRef<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = () => {
    if (!inputText.trim()) return;
    onSendMessage(inputText.trim(), 'text');
    setInputText('');
    setReplyingTo(null);
    setShowEmojiPicker(false);
    sound.playMessageSent();
  };

  const handleSmartReply = (replyText: string) => {
    onSendMessage(replyText, 'text');
    sound.playMessageSent();
  };

  // Voice note recording
  const startRecordingVoice = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const audioUrl = URL.createObjectURL(audioBlob);
        onSendMessage('🎤 Voice Message', 'audio', audioUrl, recordingSeconds);
        sound.playMessageSent();
        stream.getTracks().forEach(t => t.stop());
      };

      mediaRecorder.start();
      setIsRecordingVoice(true);
      setRecordingSeconds(0);
      recordingTimerRef.current = window.setInterval(() => {
        setRecordingSeconds(prev => prev + 1);
      }, 1000);
    } catch (err) {
      console.warn('Microphone permission required for voice notes:', err);
      // Simulated voice note fallback
      setIsRecordingVoice(true);
      setRecordingSeconds(0);
      recordingTimerRef.current = window.setInterval(() => {
        setRecordingSeconds(prev => prev + 1);
      }, 1000);
    }
  };

  const stopRecordingVoice = (send = true) => {
    if (recordingTimerRef.current) {
      clearInterval(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== 'inactive') {
      if (send) {
        mediaRecorderRef.current.stop();
      } else {
        mediaRecorderRef.current.stream.getTracks().forEach(t => t.stop());
      }
    } else if (send) {
      // Fallback synthetic voice message
      onSendMessage('🎤 Voice Note', 'audio', undefined, recordingSeconds || 4);
      sound.playMessageSent();
    }
    setIsRecordingVoice(false);
    setRecordingSeconds(0);
  };

  // Image Upload handler
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onSendMessage('📷 Photo', 'image', reader.result as string);
        sound.playMessageSent();
      };
      reader.readAsDataURL(file);
    }
  };

  const smartReplies = getSmartReplySuggestions(messages[messages.length - 1]?.text);
  const commonEmojis = ['❤️', '👍', '😂', '🔥', '🎉', '😮', '👏', '✨', '😍', '🙏'];

  return (
    <div className="flex-1 flex flex-col h-full bg-[#050817] relative select-none">
      {/* Chat Top Header */}
      <div className="h-16 px-3 sm:px-4 lg:px-6 bg-[#090e24]/90 border-b border-slate-800/80 backdrop-blur-xl flex items-center justify-between z-20">
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          {onBack && (
            <button
              onClick={onBack}
              className="p-2 -ml-1 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/60 md:hidden transition-colors cursor-pointer shrink-0"
              title="চ্যাট তালিকা"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          )}

          <div
            onClick={onOpenUserProfile}
            className="relative cursor-pointer shrink-0 group"
            title="ID কার্ড দেখুন"
          >
            {selectedUser.photoURL ? (
              <img
                src={selectedUser.photoURL}
                alt={selectedUser.name}
                className="w-10 h-10 rounded-xl object-cover ring-2 ring-cyan-400/40 group-hover:ring-cyan-400 transition-all"
              />
            ) : (
              <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${selectedUser.avatarBg || 'from-cyan-500 to-indigo-600'} flex items-center justify-center text-sm font-bold text-white ring-2 ring-cyan-400/40 group-hover:ring-cyan-400 transition-all`}>
                {getInitials(selectedUser.name)}
              </div>
            )}
            <span className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full ring-2 ring-[#090e24] ${selectedUser.online ? 'bg-emerald-400' : 'bg-slate-500'}`} />
          </div>

          <div className="min-w-0">
            <h2 className="text-sm font-bold text-white truncate flex items-center gap-2">
              <span>{selectedUser.name}</span>
            </h2>
            <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
              <span className="text-cyan-300 font-semibold">{formatVirtualId(selectedUser.virtualId)}</span>
              <span>•</span>
              <span className={selectedUser.online ? 'text-emerald-400' : 'text-slate-500'}>
                {selectedUser.online ? '🟢 অনলাইন' : 'অফলাইন'}
              </span>
            </div>
          </div>
        </div>

        {/* Action Controls: Audio & Video Call */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => onStartCall('audio')}
            className="p-2.5 rounded-xl bg-[#111735] hover:bg-cyan-500 text-cyan-300 hover:text-slate-950 border border-cyan-500/30 font-bold transition-all shadow-md active:scale-95 flex items-center gap-1.5"
            title="Start HD Audio Call"
          >
            <Phone className="w-4 h-4" />
            <span className="hidden sm:inline text-xs font-semibold">Audio</span>
          </button>

          <button
            onClick={() => onStartCall('video')}
            className="p-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold transition-all shadow-lg shadow-cyan-500/25 active:scale-95 flex items-center gap-1.5"
            title="Start HD Video Call"
          >
            <Video className="w-4 h-4" />
            <span className="hidden sm:inline text-xs font-semibold">Video</span>
          </button>
        </div>
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
        {/* Encrypted Notice Pill */}
        <div className="flex justify-center">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#0d142e] border border-cyan-500/20 text-slate-400 text-[11px]">
            <Sparkles className="w-3 h-3 text-cyan-400" />
            <span>কলরা ভার্চুয়াল নেটওয়ার্কে এন্ড-টু-এন্ড সুরক্ষিত চ্যাট</span>
          </div>
        </div>

        {messages.length === 0 && (
          <div className="py-12 px-4 text-center max-w-sm mx-auto space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-cyan-950/50 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mx-auto shadow-lg shadow-cyan-500/10">
              <MessageSquare className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white mb-1">
                {selectedUser.name}-এর সাথে চ্যাট শুরু করুন
              </h3>
              <p className="text-xs text-slate-400">
                ভার্চুয়াল আইডি: <span className="text-cyan-300 font-mono font-bold">{formatVirtualId(selectedUser.virtualId)}</span>
              </p>
            </div>

            <div className="pt-2 flex flex-col gap-2">
              <span className="text-[11px] text-slate-500 font-medium">কুইক মেসেজ পাঠান:</span>
              <div className="flex flex-wrap justify-center gap-1.5">
                {[
                  '👋 আসসালামু আলাইকুম!',
                  '✨ Callora-তে স্বাগতম!',
                  '📞 একটি অডিও কল দিতে পারি?',
                  '📹 ভিডিও কল টেস্ট করবেন?'
                ].map((icebreaker) => (
                  <button
                    key={icebreaker}
                    onClick={() => onSendMessage(icebreaker)}
                    className="px-3 py-1.5 rounded-xl bg-[#111838] hover:bg-cyan-500 hover:text-slate-950 text-cyan-300 text-xs font-medium border border-cyan-500/20 transition-all cursor-pointer shadow-sm"
                  >
                    {icebreaker}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {messages.map((msg) => {
          const isMe = msg.senderId === currentUser.uid;

          return (
            <div
              key={msg.id}
              className={`flex flex-col group ${isMe ? 'items-end' : 'items-start'}`}
            >
              <div className="flex items-end gap-2 max-w-[85%] sm:max-w-[70%]">
                {!isMe && (
                  <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-cyan-500 to-indigo-600 flex items-center justify-center text-xs font-bold text-white shrink-0 mb-1">
                    {getInitials(selectedUser.name)}
                  </div>
                )}

                <div
                  className={`relative p-3.5 rounded-2xl text-sm leading-relaxed shadow-lg ${
                    isMe
                      ? 'bg-gradient-to-r from-[#603bda] to-[#7f39f8] text-white rounded-br-none border border-purple-400/20'
                      : 'bg-[#101735] text-slate-100 rounded-bl-none border border-slate-800'
                  }`}
                >
                  {/* Photo attachment */}
                  {msg.type === 'image' && msg.mediaUrl && (
                    <div className="mb-2 rounded-xl overflow-hidden cursor-pointer" onClick={() => setSelectedImageModal(msg.mediaUrl!)}>
                      <img src={msg.mediaUrl} alt="Attachment" className="max-h-60 rounded-xl object-cover hover:scale-105 transition-transform" />
                    </div>
                  )}

                  {/* Voice note waveform */}
                  {msg.type === 'audio' && (
                    <div className="flex items-center gap-3 py-1">
                      <button
                        onClick={() => {
                          setPlayingAudioId(playingAudioId === msg.id ? null : msg.id);
                        }}
                        className="w-9 h-9 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition-colors"
                      >
                        {playingAudioId === msg.id ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 ml-0.5" />}
                      </button>

                      <div className="flex-1">
                        <div className="flex items-center gap-1 h-5">
                          {[40, 70, 30, 90, 60, 45, 85, 50, 65, 30, 80, 40].map((h, i) => (
                            <span
                              key={i}
                              style={{ height: `${playingAudioId === msg.id ? Math.max(15, Math.round(h * Math.random())) : h}%` }}
                              className={`w-1 rounded-full ${isMe ? 'bg-white/80' : 'bg-cyan-400/80'} transition-all`}
                            />
                          ))}
                        </div>
                        <span className="text-[10px] text-white/70 font-mono">0:{msg.audioDuration ? String(msg.audioDuration).padStart(2, '0') : '04'}</span>
                      </div>
                    </div>
                  )}

                  {/* Text content */}
                  {msg.text && msg.type !== 'audio' && (
                    <p className="whitespace-pre-wrap break-words">{msg.text}</p>
                  )}

                  {/* Message Time and Status Tick */}
                  <div className="flex items-center justify-end gap-1.5 mt-1 text-[10px] text-white/60 font-mono">
                    <span>{formatTimestamp(msg.createdAt)}</span>
                    {isMe && (
                      <span>
                        <CheckCheck className="w-3.5 h-3.5 text-cyan-300" />
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Reaction display */}
              {msg.reactions && Object.keys(msg.reactions).length > 0 && (
                <div className={`flex gap-1 mt-1 ${isMe ? 'mr-2' : 'ml-9'}`}>
                  {Object.entries(msg.reactions).map(([emoji, userList]) => {
                    const count = Array.isArray(userList) ? userList.length : 1;
                    return (
                      <span key={emoji} className="px-2 py-0.5 rounded-full bg-[#151c3a] border border-slate-700 text-xs shadow-md">
                        {emoji} {count > 1 && count}
                      </span>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* AI Smart Reply Suggestions Bar */}
      <div className="px-4 py-1.5 bg-[#090e24]/70 border-t border-slate-800/40 flex items-center gap-2 overflow-x-auto no-scrollbar">
        <span className="text-[11px] font-bold text-cyan-400 flex items-center gap-1 shrink-0">
          <Sparkles className="w-3 h-3" />
          <span>AI কুইক রিপ্লাই:</span>
        </span>
        {smartReplies.map((reply, index) => (
          <button
            key={index}
            onClick={() => handleSmartReply(reply)}
            className="whitespace-nowrap shrink-0 px-3 py-1 rounded-full bg-[#12193b] hover:bg-cyan-950/80 border border-slate-700/80 hover:border-cyan-500/40 text-slate-300 hover:text-cyan-300 text-xs transition-all active:scale-95"
          >
            {reply}
          </button>
        ))}
      </div>

      {/* Emoji Drawer */}
      {showEmojiPicker && (
        <div className="p-3 bg-[#0d1433] border-t border-slate-800 flex items-center gap-2 flex-wrap animate-in fade-in">
          {commonEmojis.map(emoji => (
            <button
              key={emoji}
              onClick={() => {
                setInputText(prev => prev + emoji);
              }}
              className="text-xl p-2 rounded-xl hover:bg-slate-800 transition-transform hover:scale-125"
            >
              {emoji}
            </button>
          ))}
        </div>
      )}

      {/* Chat Bottom Input Toolbar */}
      <div className="p-3 sm:p-4 bg-[#090e24] border-t border-slate-800/80">
        {isRecordingVoice ? (
          /* Live Voice Recording UI */
          <div className="flex items-center justify-between p-3 rounded-2xl bg-rose-950/40 border border-rose-500/40 text-rose-300 animate-pulse">
            <div className="flex items-center gap-2.5">
              <span className="w-3 h-3 rounded-full bg-rose-500 animate-ping" />
              <span className="text-xs font-bold font-mono">ভয়েস রেকর্ড হচ্ছে... 0:{String(recordingSeconds).padStart(2, '0')}</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => stopRecordingVoice(false)}
                className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold"
              >
                বাতিল
              </button>
              <button
                onClick={() => stopRecordingVoice(true)}
                className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-lg"
              >
                পাঠান
              </button>
            </div>
          </div>
        ) : (
          /* Regular Message Composer */
          <div className="flex items-center gap-2">
            {/* Attachment Button */}
            <input
              type="file"
              ref={fileInputRef}
              accept="image/*"
              className="hidden"
              onChange={handleImageUpload}
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="p-2.5 rounded-xl bg-[#111735] hover:bg-[#162048] text-slate-400 hover:text-cyan-300 border border-slate-800 transition-colors"
              title="Attach Photo"
            >
              <ImageIcon className="w-5 h-5" />
            </button>

            {/* Emoji Toggle */}
            <button
              type="button"
              onClick={() => setShowEmojiPicker(!showEmojiPicker)}
              className="p-2.5 rounded-xl bg-[#111735] hover:bg-[#162048] text-slate-400 hover:text-cyan-300 border border-slate-800 transition-colors"
              title="Add Emoji"
            >
              <Smile className="w-5 h-5" />
            </button>

            {/* Main Text Input */}
            <div className="flex-1 relative">
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') handleSend();
                }}
                placeholder="মেসেজ লিখুন..."
                className="w-full py-3 px-4 bg-[#111735] border border-slate-700/80 rounded-2xl text-white placeholder-slate-500 text-sm focus:outline-none focus:border-cyan-400 transition-colors"
              />
            </div>

            {/* Mic / Voice Note Record Button */}
            <button
              type="button"
              onClick={startRecordingVoice}
              className="p-2.5 rounded-xl bg-[#111735] hover:bg-[#162048] text-slate-400 hover:text-cyan-300 border border-slate-800 transition-colors"
              title="Record Voice Note"
            >
              <Mic className="w-5 h-5" />
            </button>

            {/* Send Button */}
            <button
              type="button"
              onClick={handleSend}
              disabled={!inputText.trim()}
              className="p-3 rounded-2xl bg-gradient-to-r from-cyan-500 via-indigo-600 to-fuchsia-600 hover:from-cyan-400 hover:to-fuchsia-500 text-white font-bold shadow-lg shadow-cyan-500/25 transition-all transform active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed"
              title="Send Message"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>

      {/* Lightbox Image Preview Modal */}
      {selectedImageModal && (
        <div
          onClick={() => setSelectedImageModal(null)}
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4"
        >
          <img src={selectedImageModal} alt="Preview" className="max-w-full max-h-full rounded-2xl shadow-2xl" />
        </div>
      )}
    </div>
  );
};
