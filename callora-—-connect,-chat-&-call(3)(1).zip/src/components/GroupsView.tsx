import React, { useState } from 'react';
import {
  Users,
  Plus,
  MessageSquare,
  Phone,
  Video,
  Sparkles,
  Search,
  Check,
  X
} from 'lucide-react';
import { UserProfile, GroupDetails } from '../types';

interface GroupsViewProps {
  currentUser: UserProfile;
  contacts: UserProfile[];
  onOpenGroupChat: (group: GroupDetails) => void;
  onStartGroupCall: (group: GroupDetails, type: 'audio' | 'video') => void;
}

export const GroupsView: React.FC<GroupsViewProps> = ({
  currentUser,
  contacts,
  onOpenGroupChat,
  onStartGroupCall
}) => {
  const [groups, setGroups] = useState<GroupDetails[]>([]);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupDesc, setNewGroupDesc] = useState('');
  const [newGroupEmoji, setNewGroupEmoji] = useState('🚀');
  const [selectedMemberUids, setSelectedMemberUids] = useState<string[]>([]);
  const [searchFilter, setSearchFilter] = useState('');

  const handleCreateGroup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGroupName.trim()) return;

    const newGroup: GroupDetails = {
      id: `grp_${Date.now()}`,
      name: `${newGroupEmoji} ${newGroupName.trim()}`,
      description: newGroupDesc.trim() || 'Callora Group Space',
      avatar: newGroupEmoji,
      createdBy: currentUser.uid,
      admins: [currentUser.uid],
      members: [currentUser.uid, ...selectedMemberUids],
      createdAt: Date.now()
    };

    setGroups([newGroup, ...groups]);
    setShowCreateModal(false);
    setNewGroupName('');
    setNewGroupDesc('');
    setSelectedMemberUids([]);
  };

  const toggleMemberSelection = (uid: string) => {
    if (selectedMemberUids.includes(uid)) {
      setSelectedMemberUids(selectedMemberUids.filter((id) => id !== uid));
    } else {
      setSelectedMemberUids([...selectedMemberUids, uid]);
    }
  };

  const filteredGroups = groups.filter(
    (g) =>
      g.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
      g.description.toLowerCase().includes(searchFilter.toLowerCase())
  );

  return (
    <div className="flex-1 flex flex-col h-full bg-[#050817] p-3 sm:p-6 lg:p-8 overflow-y-auto select-none pb-24 md:pb-8">
      <div className="max-w-4xl mx-auto w-full space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-gradient-to-r from-[#0c1433] via-[#0e173b] to-[#161a45] p-6 rounded-3xl border border-cyan-500/20 shadow-xl">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/70 border border-cyan-400/30 text-cyan-300 text-xs font-semibold uppercase tracking-wider mb-2">
              <Users className="w-3.5 h-3.5" />
              <span>Callora Groups & Spaces</span>
            </div>
            <h2 className="text-2xl font-black text-white">গ্রুপ ও স্পেস</h2>
            <p className="text-xs text-slate-400 mt-1">
              একাধিক বন্ধুর সাথে একসাথে গ্রুপ চ্যাট ও গ্রুপ কনফারেন্স করুন
            </p>
          </div>

          <button
            onClick={() => setShowCreateModal(true)}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>নতুন গ্রুপ তৈরি করুন</span>
          </button>
        </div>

        {/* Search if groups exist */}
        {groups.length > 0 && (
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              placeholder="গ্রুপ খুঁজুন..."
              className="w-full pl-10 pr-4 py-2.5 bg-[#0e142f] border border-slate-800 rounded-xl text-white placeholder-slate-500 text-xs focus:outline-none focus:border-cyan-400"
            />
          </div>
        )}

        {/* Empty State */}
        {groups.length === 0 ? (
          <div className="bg-[#0c1228]/80 border border-slate-800 rounded-3xl p-8 sm:p-12 text-center flex flex-col items-center justify-center">
            <div className="w-16 h-16 rounded-2xl bg-cyan-950/50 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-4 shadow-[0_0_30px_rgba(0,217,255,0.15)]">
              <Users className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-white mb-1">কোনো সক্রিয় গ্রুপ নেই</h3>
            <p className="text-xs text-slate-400 max-w-md mb-6 leading-relaxed">
              আপনি এখনো কোনো গ্রুপ তৈরি করেননি। বন্ধুদের সাথে একসাথে আড্ডা ও গ্রুপ অডিও-ভিডিও কনফারেন্স করতে নতুন গ্রুপ খুলুন।
            </p>
            <button
              onClick={() => setShowCreateModal(true)}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-cyan-500/20 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>প্রথম গ্রুপ তৈরি করুন</span>
            </button>
          </div>
        ) : (
          /* Group Cards Grid */
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredGroups.map((grp) => (
              <div
                key={grp.id}
                className="p-5 rounded-2xl bg-[#0c1228] border border-slate-800 hover:border-cyan-500/40 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-3 mb-2">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center text-2xl shadow-md border border-white/10">
                        {grp.avatar || '👥'}
                      </div>
                      <div>
                        <h4 className="text-sm font-bold text-white">{grp.name}</h4>
                        <span className="text-[11px] text-cyan-300 font-medium">
                          {grp.members.length} জন সদস্য
                        </span>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-slate-400 mb-4">{grp.description}</p>
                </div>

                <div className="flex items-center gap-2 pt-3 border-t border-slate-800">
                  <button
                    onClick={() => onOpenGroupChat(grp)}
                    className="flex-1 py-2 px-3 rounded-xl bg-[#12193b] hover:bg-cyan-500 hover:text-slate-950 text-cyan-300 text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>গ্রুপ চ্যাট</span>
                  </button>

                  <button
                    onClick={() => onStartGroupCall(grp, 'audio')}
                    className="p-2 rounded-xl bg-[#12193b] hover:bg-[#1b2656] text-slate-300 hover:text-cyan-300 border border-slate-700/60 transition-colors cursor-pointer"
                    title="Group Voice Call"
                  >
                    <Phone className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onStartGroupCall(grp, 'video')}
                    className="p-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-white shadow-md shadow-cyan-500/20 transition-all cursor-pointer"
                    title="Group Video Call"
                  >
                    <Video className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Create Group Modal */}
        {showCreateModal && (
          <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="bg-[#0c1228] border border-slate-700 w-full max-w-md rounded-3xl p-6 shadow-2xl animate-in zoom-in-95">
              <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-cyan-400" />
                  <span>নতুন গ্রুপ তৈরি করুন</span>
                </h3>
                <button
                  onClick={() => setShowCreateModal(false)}
                  className="p-1 rounded-lg text-slate-400 hover:text-white cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleCreateGroup} className="space-y-4 mt-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    গ্রুপ আইকন / ইমোজি
                  </label>
                  <div className="flex gap-2">
                    {['🚀', '💻', '🎨', '🏡', '🎮', '⚡', '🌟', '🔥'].map((emoji) => (
                      <button
                        key={emoji}
                        type="button"
                        onClick={() => setNewGroupEmoji(emoji)}
                        className={`w-9 h-9 rounded-xl text-lg flex items-center justify-center transition-all cursor-pointer ${
                          newGroupEmoji === emoji
                            ? 'bg-cyan-500 text-black scale-110 shadow-lg shadow-cyan-500/30'
                            : 'bg-[#111735] hover:bg-slate-800 text-white'
                        }`}
                      >
                        {emoji}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    গ্রুপের নাম
                  </label>
                  <input
                    type="text"
                    required
                    value={newGroupName}
                    onChange={(e) => setNewGroupName(e.target.value)}
                    placeholder="যেমন: ডেভেলপারস টিম"
                    className="w-full px-4 py-2.5 bg-[#111735] border border-slate-700 rounded-xl text-white placeholder-slate-500 text-xs focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    বিবরণ (Description)
                  </label>
                  <textarea
                    rows={2}
                    value={newGroupDesc}
                    onChange={(e) => setNewGroupDesc(e.target.value)}
                    placeholder="গ্রুপের উদ্দেশ্য লিখুন..."
                    className="w-full px-4 py-2 bg-[#111735] border border-slate-700 rounded-xl text-white placeholder-slate-500 text-xs focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    কন্ট্যাক্টস থেকে মেম্বার যুক্ত করুন ({selectedMemberUids.length})
                  </label>
                  {contacts.length === 0 ? (
                    <p className="text-[11px] text-slate-500 p-3 bg-[#111735] rounded-xl">
                      আপনার কন্ট্যাক্ট তালিকায় এখনো কেউ নেই। আপনি পরে ভার্চুয়াল আইডি দিয়ে মেম্বার যোগ করতে পারবেন।
                    </p>
                  ) : (
                    <div className="max-h-36 overflow-y-auto space-y-1 bg-[#111735] p-2 rounded-xl border border-slate-800">
                      {contacts.map((contact) => {
                        const isSelected = selectedMemberUids.includes(contact.uid);
                        return (
                          <div
                            key={contact.uid}
                            onClick={() => toggleMemberSelection(contact.uid)}
                            className={`p-2 rounded-lg flex items-center justify-between cursor-pointer transition-colors ${
                              isSelected ? 'bg-cyan-950/70 border border-cyan-500/30' : 'hover:bg-slate-800/60'
                            }`}
                          >
                            <span className="text-xs text-white font-medium">{contact.name}</span>
                            {isSelected && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowCreateModal(false)}
                    className="flex-1 py-2.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold hover:bg-slate-700 cursor-pointer"
                  >
                    বাতিল
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-white text-xs font-bold shadow-lg shadow-cyan-500/25 cursor-pointer"
                  >
                    গ্রুপ তৈরি করুন
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
