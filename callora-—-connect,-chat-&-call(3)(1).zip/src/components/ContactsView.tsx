import React, { useState } from 'react';
import {
  UserPlus,
  Search,
  Phone,
  Video,
  MessageSquare,
  Sparkles,
  QrCode,
  Copy,
  Check,
  Plus,
  Share2,
  Trash2
} from 'lucide-react';
import { UserProfile } from '../types';
import { formatVirtualId, getInitials } from '../services/firebase';

interface ContactsViewProps {
  currentUser: UserProfile;
  contacts: UserProfile[];
  onSelectChatUser: (user: UserProfile) => void;
  onStartCall: (user: UserProfile, type: 'audio' | 'video') => void;
  onOpenIdCard: () => void;
  onAddContact: (virtualId: string) => Promise<boolean>;
  onRemoveContact?: (uid: string) => void;
}

export const ContactsView: React.FC<ContactsViewProps> = ({
  currentUser,
  contacts,
  onSelectChatUser,
  onStartCall,
  onOpenIdCard,
  onAddContact,
  onRemoveContact
}) => {
  const [filterQuery, setFilterQuery] = useState('');
  const [newVirtualId, setNewVirtualId] = useState('');
  const [addingStatus, setAddingStatus] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const filteredContacts = contacts.filter(
    (c) =>
      c.name.toLowerCase().includes(filterQuery.toLowerCase()) ||
      c.virtualId.includes(filterQuery) ||
      (c.username && c.username.toLowerCase().includes(filterQuery.toLowerCase()))
  );

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanId = newVirtualId.replace(/\s+/g, '').trim();
    if (!cleanId) return;

    if (cleanId === currentUser.virtualId) {
      setAddingStatus('⚠️ এটি আপনার নিজের ভার্চুয়াল আইডি।');
      setTimeout(() => setAddingStatus(null), 3000);
      return;
    }

    setAddingStatus('অনলাইনে খোঁজা হচ্ছে...');
    const success = await onAddContact(cleanId);
    if (success) {
      setAddingStatus('✅ কন্ট্যাক্ট সফলভাবে যুক্ত হয়েছে!');
      setNewVirtualId('');
      setTimeout(() => setAddingStatus(null), 2500);
    } else {
      setAddingStatus('❌ এই Virtual ID-এর কোনো অ্যাকাউন্ট পাওয়া যায়নি। সঠিক ১১-সংখ্যার আইডি দিন।');
      setTimeout(() => setAddingStatus(null), 3500);
    }
  };

  const handleCopyMyId = () => {
    navigator.clipboard.writeText(currentUser.virtualId);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  const handleCopyInviteLink = () => {
    const inviteUrl = `${window.location.origin}/#id=${currentUser.virtualId}`;
    navigator.clipboard.writeText(inviteUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#050817] p-3 sm:p-6 lg:p-8 overflow-y-auto select-none pb-24 md:pb-8">
      {/* Header Banner */}
      <div className="max-w-4xl mx-auto w-full space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-gradient-to-r from-[#0c1433] via-[#0e173b] to-[#161a45] p-6 rounded-3xl border border-cyan-500/20 shadow-xl">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/70 border border-cyan-400/30 text-cyan-300 text-xs font-semibold uppercase tracking-wider mb-2">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Callora Contact Book</span>
            </div>
            <h2 className="text-2xl font-black text-white">আপনার কন্ট্যাক্ট তালিকা</h2>
            <p className="text-xs text-slate-400 mt-1">
              যেকোনো Callora ব্যবহারকারীর সাথে সরাসরি ফ্রি কল ও এনক্রিপ্টেড চ্যাট করুন
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={onOpenIdCard}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-bold flex items-center gap-2 shadow-lg shadow-cyan-500/25 transition-all cursor-pointer"
            >
              <QrCode className="w-4 h-4" />
              <span>আমার ID কার্ড</span>
            </button>

            <button
              onClick={handleCopyInviteLink}
              className="px-3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1.5 border border-slate-700 cursor-pointer"
              title="Copy Direct Invite Link"
            >
              {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
              <span>{copiedLink ? 'লিঙ্ক কপি হয়েছে' : 'ইনভাইট লিঙ্ক'}</span>
            </button>

            <button
              onClick={handleCopyMyId}
              className="px-3 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold flex items-center gap-1.5 border border-slate-700 cursor-pointer"
              title="Copy Virtual ID"
            >
              {copiedId ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copiedId ? 'কপি হয়েছে' : 'ID কপি'}</span>
            </button>
          </div>
        </div>

        {/* Add New Contact by 11-digit Virtual ID Box */}
        <div className="bg-[#0c1228] p-5 rounded-2xl border border-slate-800 shadow-md">
          <h3 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
            <UserPlus className="w-4 h-4 text-cyan-400" />
            <span>নতুন Virtual ID দিয়ে কন্ট্যাক্ট যুক্ত করুন</span>
          </h3>

          <form onSubmit={handleAddSubmit} className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              value={newVirtualId}
              onChange={(e) => setNewVirtualId(e.target.value)}
              placeholder="১১-সংখ্যার Virtual ID লিখুন (যেমন: 21088492011)"
              className="flex-1 px-4 py-2.5 bg-[#111735] border border-slate-700/80 rounded-xl text-white placeholder-slate-500 text-xs focus:outline-none focus:border-cyan-400 font-mono"
            />
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>যুক্ত করুন</span>
            </button>
          </form>

          {addingStatus && (
            <p className="text-xs mt-2 font-medium text-cyan-300">{addingStatus}</p>
          )}
        </div>

        {/* Search Contacts Filter if there are contacts */}
        {contacts.length > 0 && (
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={filterQuery}
              onChange={(e) => setFilterQuery(e.target.value)}
              placeholder="সংরক্ষিত কন্ট্যাক্ট নাম বা Virtual ID দিয়ে খুঁজুন..."
              className="w-full pl-10 pr-4 py-2.5 bg-[#0e142f] border border-slate-800 rounded-xl text-white placeholder-slate-500 text-xs focus:outline-none focus:border-cyan-400"
            />
          </div>
        )}

        {/* Empty State when no contacts exist */}
        {contacts.length === 0 ? (
          <div className="bg-[#0c1228]/80 border border-slate-800/80 rounded-3xl p-8 sm:p-12 text-center flex flex-col items-center justify-center">
            <div className="w-16 h-16 rounded-2xl bg-cyan-950/50 border border-cyan-500/30 flex items-center justify-center text-cyan-400 mb-4 shadow-[0_0_30px_rgba(0,217,255,0.15)]">
              <UserPlus className="w-8 h-8" />
            </div>

            <h3 className="text-lg font-bold text-white mb-1">
              আপনার কন্ট্যাক্ট তালিকা বর্তমানে খালি
            </h3>
            <p className="text-xs text-slate-400 max-w-md mb-6 leading-relaxed">
              আপনি এখনো কারো সাথে যোগাযোগ করেননি। বন্ধুদের আপনার ১১-সংখ্যার Virtual ID শেয়ার করুন অথবা তাদের আইডি দিয়ে সার্চ করে সরাসরি কথা বলুন।
            </p>

            <div className="flex flex-wrap items-center justify-center gap-3">
              <div className="flex items-center gap-2 px-4 py-2 bg-[#111735] border border-cyan-500/30 rounded-xl">
                <span className="text-xs text-slate-400">আপনার ID:</span>
                <span className="text-xs text-cyan-300 font-mono font-bold">
                  {formatVirtualId(currentUser.virtualId)}
                </span>
                <button
                  onClick={handleCopyMyId}
                  className="p-1 text-slate-400 hover:text-cyan-300 cursor-pointer"
                >
                  {copiedId ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>

              <button
                onClick={onOpenIdCard}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs font-bold flex items-center gap-1.5 shadow-md shadow-cyan-500/20 cursor-pointer"
              >
                <QrCode className="w-4 h-4" />
                <span>QR কোড কার্ড খুলুন</span>
              </button>
            </div>
          </div>
        ) : filteredContacts.length === 0 ? (
          <div className="text-center py-8 text-slate-400">
            <p className="text-xs">"{filterQuery}" দিয়ে কোনো কন্ট্যাক্ট পাওয়া যায়নি।</p>
          </div>
        ) : (
          /* Contact Cards Grid */
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {filteredContacts.map((contact) => (
              <div
                key={contact.uid}
                className="p-4 rounded-2xl bg-[#0c1228] border border-slate-800 hover:border-cyan-500/40 transition-all flex flex-col justify-between group"
              >
                <div className="flex items-start gap-3.5 mb-3">
                  <div className="relative shrink-0">
                    {contact.photoURL ? (
                      <img src={contact.photoURL} alt={contact.name} className="w-12 h-12 rounded-xl object-cover" />
                    ) : (
                      <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${contact.avatarBg || 'from-cyan-500 to-indigo-600'} flex items-center justify-center text-base font-bold text-white`}>
                        {getInitials(contact.name)}
                      </div>
                    )}
                    <span className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full ring-2 ring-[#0c1228] ${contact.online ? 'bg-emerald-400' : 'bg-slate-600'}`} />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <h4 className="text-sm font-bold text-white truncate">{contact.name}</h4>
                      <span className="text-[10px] text-emerald-400 font-medium">
                        {contact.online ? 'Online' : 'Offline'}
                      </span>
                    </div>

                    <span className="text-xs text-cyan-300 font-mono block mt-0.5">
                      {formatVirtualId(contact.virtualId)}
                    </span>
                    <p className="text-[11px] text-slate-400 truncate mt-1">
                      {contact.statusText || contact.bio || 'Callora User'}
                    </p>
                  </div>
                </div>

                {/* Action Buttons: Chat, Audio, Video */}
                <div className="flex items-center gap-1.5 pt-3 border-t border-slate-800/80">
                  <button
                    onClick={() => onSelectChatUser(contact)}
                    className="flex-1 py-2 px-2.5 rounded-xl bg-[#12193b] hover:bg-cyan-500 hover:text-slate-950 text-cyan-300 text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
                    title="Open Chat"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>চ্যাট</span>
                  </button>

                  <button
                    onClick={() => onStartCall(contact, 'audio')}
                    className="p-2 rounded-xl bg-[#12193b] hover:bg-[#1b2656] text-slate-300 hover:text-cyan-300 border border-slate-700/60 transition-colors cursor-pointer"
                    title="Audio Call"
                  >
                    <Phone className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onStartCall(contact, 'video')}
                    className="p-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-white transition-all shadow-md shadow-cyan-500/20 cursor-pointer"
                    title="Video Call"
                  >
                    <Video className="w-4 h-4" />
                  </button>

                  {onRemoveContact && (
                    <button
                      onClick={() => onRemoveContact(contact.uid)}
                      className="p-2 rounded-xl bg-[#12193b] hover:bg-rose-950/60 text-slate-400 hover:text-rose-300 border border-slate-800 transition-colors cursor-pointer"
                      title="কন্ট্যাক্ট মুছুন"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
